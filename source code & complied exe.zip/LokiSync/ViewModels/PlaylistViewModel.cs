using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using LokiSync.Models;

namespace LokiSync.ViewModels;

/// <summary>
/// UI-facing wrapper for a Playlist. Holds resolved Track objects for
/// binding; the underlying Playlist model only stores file paths.
/// </summary>
public sealed class PlaylistViewModel : ObservableObject
{
    public Playlist Model { get; }

    private string _name;
    public string Name
    {
        get => _name;
        private set => SetField(ref _name, value);
    }

    private bool _isEditing;
    /// <summary>True while the sidebar is showing an inline rename TextBox for this playlist.</summary>
    public bool IsEditing
    {
        get => _isEditing;
        set => SetField(ref _isEditing, value);
    }

    private string _editingName = string.Empty;
    /// <summary>
    /// Scratch buffer the rename TextBox binds to. Kept separate from Name
    /// so that a user selecting all + deleting mid-rename (a completely
    /// normal way to start typing a replacement) doesn't briefly hit an
    /// empty Name, trip the "no blank names" guard, and force a
    /// PropertyChanged that snaps the TextBox back to the old text out
    /// from under the caret while they're still typing. Name itself is
    /// only ever touched once, on commit.
    /// </summary>
    public string EditingName
    {
        get => _editingName;
        set => SetField(ref _editingName, value);
    }

    public ObservableCollection<Track> Tracks { get; } = new();

    /// <summary>"3 tracks · 12:04" style summary shown under the playlist name.</summary>
    public string SummaryDisplay
    {
        get
        {
            int count = Tracks.Count;
            var total = System.TimeSpan.FromSeconds(Tracks.Sum(t => t.Duration.TotalSeconds));
            string countText = count == 1 ? "1 track" : $"{count} tracks";
            if (total <= System.TimeSpan.Zero) return countText;
            string timeText = total.TotalHours >= 1
                ? total.ToString(@"h\:mm\:ss")
                : total.ToString(@"m\:ss");
            return $"{countText} · {timeText}";
        }
    }

    public PlaylistViewModel(Playlist model)
    {
        Model = model;
        _name = model.Name;
        Tracks.CollectionChanged += OnTracksCollectionChanged;
    }

    /// <summary>Enter rename mode, seeding the edit buffer with the current name.</summary>
    public void BeginEdit()
    {
        EditingName = Name;
        IsEditing = true;
    }

    /// <summary>
    /// Commit whatever is in the edit buffer as the new name (trimmed;
    /// blank or unchanged input is a no-op that just closes the editor)
    /// and leave edit mode.
    /// </summary>
    public void CommitEdit()
    {
        var trimmed = EditingName.Trim();
        if (!string.IsNullOrEmpty(trimmed) && trimmed != Model.Name)
        {
            Model.Name = trimmed;
            Name = trimmed;
        }

        IsEditing = false;
    }

    /// <summary>Discard the edit buffer and leave edit mode without touching Name.</summary>
    public void CancelEdit()
    {
        IsEditing = false;
    }

    private void OnTracksCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) =>
        OnPropertyChanged(nameof(SummaryDisplay));

    public override string ToString() => Name;
}
