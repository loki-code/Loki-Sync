using System;

namespace LokiSync.ViewModels;

/// <summary>
/// UI-facing wrapper for a single graphic EQ band. Each instance mirrors
/// one entry of EqualizerSampleProvider.BandFrequencies and exposes it as
/// a bindable gain (dB) plus a couple of display-friendly derived values
/// (frequency label, normalized 0..1 vertical position) that the custom
/// EqCurveControl and the fallback slider list both bind against.
///
/// Kept as a thin, mostly-passive object — MainViewModel still owns "what
/// happens on change" (pushing to PlaybackService, persisting, clearing
/// the selected preset) via the callback passed into the constructor,
/// the same delegation pattern PlaylistViewModel uses for rename commits.
/// </summary>
public sealed class EqBandViewModel : ObservableObject
{
    private readonly Action<int, float> _onGainChanged;

    public int Index { get; }
    public double FrequencyHz { get; }

    /// <summary>Short label for the band, e.g. "32" or "8k" — matches how graphic EQs conventionally label bands.</summary>
    public string FrequencyLabel { get; }

    private float _gainDb;
    /// <summary>Gain in dB, -12..+12. Setting this pushes to PlaybackService and marks the EQ as hand-tweaked.</summary>
    public float GainDb
    {
        get => _gainDb;
        set
        {
            value = Math.Clamp(value, -12f, 12f);
            if (!SetField(ref _gainDb, value)) return;
            OnPropertyChanged(nameof(NormalizedGain));
            OnPropertyChanged(nameof(GainLabel));
            _onGainChanged(Index, value);
        }
    }

    /// <summary>Gain remapped to 0..1 (0 = -12dB, 0.5 = 0dB, 1 = +12dB), for positioning a dot on the curve control.</summary>
    public double NormalizedGain => (GainDb + 12f) / 24f;

    public string GainLabel => GainDb switch
    {
        0 => "0 dB",
        > 0 => $"+{GainDb:0.#} dB",
        _ => $"{GainDb:0.#} dB"
    };

    public EqBandViewModel(int index, double frequencyHz, float initialGainDb, Action<int, float> onGainChanged)
    {
        Index = index;
        FrequencyHz = frequencyHz;
        FrequencyLabel = FormatFrequency(frequencyHz);
        _onGainChanged = onGainChanged;
        _gainDb = initialGainDb;
    }

    private static string FormatFrequency(double hz) =>
        hz >= 1000 ? $"{hz / 1000:0.#}k" : $"{hz:0}";
}
