using System;
using NAudio.Dsp;
using NAudio.Wave;

namespace LokiSync.Audio;

/// <summary>
/// Wraps a stereo, 32-bit float source with a real N-band graphic
/// equalizer (one peaking BiQuad filter per band, centered on a fixed
/// log-spaced frequency ladder) plus a stereo balance control, all
/// applied per-sample in real time. This is the actual DSP behind the
/// Settings panel's graphic EQ curve — NAudio's built-in BiQuadFilter
/// does the filtering; this class just owns one filter instance per
/// channel per band (stereo needs independent filter state per channel,
/// so a single shared filter would smear left/right) and re-designs a
/// band's filter whenever its gain changes.
///
/// This replaces the previous fixed bass/mid/treble shelf-filter design:
/// a graphic EQ with many independently adjustable peaking bands gives a
/// much closer match to a "drag points on a curve" UI, since every band
/// on screen maps 1:1 to a filter here rather than three broad regions
/// covering the whole spectrum.
/// </summary>
public sealed class EqualizerSampleProvider : ISampleProvider
{
    /// <summary>
    /// Center frequencies (Hz) for each band, low to high. Roughly
    /// one-octave spacing, which is what makes a 9-point curve still feel
    /// continuous rather than sparse. Shared with the ViewModel so the UI
    /// labels and the actual filters can never drift out of sync.
    /// </summary>
    public static readonly double[] BandFrequencies =
    {
        32, 64, 125, 250, 500, 1000, 2000, 4000, 8000
    };

    public const int BandCount = 9;

    private readonly ISampleProvider _source;

    // One filter instance per channel (0=left, 1=right) per band. Filters
    // are stateful (they remember previous samples to compute the next
    // output), so left and right MUST NOT share an instance or channels
    // would bleed into each other's filter history.
    private readonly BiQuadFilter[,] _filters = new BiQuadFilter[BandCount, 2];
    private readonly float[] _gainsDb = new float[BandCount];

    private float _balance; // -1 (full left) .. 0 (center) .. 1 (full right)

    public WaveFormat WaveFormat => _source.WaveFormat;

    public EqualizerSampleProvider(ISampleProvider source)
    {
        if (source.WaveFormat.Channels != 2)
            throw new ArgumentException("EqualizerSampleProvider requires a stereo source.", nameof(source));

        _source = source;

        for (int band = 0; band < BandCount; band++)
            for (int ch = 0; ch < 2; ch++)
                _filters[band, ch] = MakeFilter(band, 0f);
    }

    /// <summary>Gets the current gain (dB, -12..+12) for a band.</summary>
    public float GetBandGainDb(int band) => _gainsDb[band];

    /// <summary>Sets the gain (dB) for a single band and redesigns its filters.</summary>
    public void SetBandGainDb(int band, float gainDb)
    {
        if (band < 0 || band >= BandCount) return;

        gainDb = Math.Clamp(gainDb, -12f, 12f);
        if (Math.Abs(_gainsDb[band] - gainDb) < 0.01f) return;

        _gainsDb[band] = gainDb;
        for (int ch = 0; ch < 2; ch++)
            _filters[band, ch] = MakeFilter(band, gainDb);
    }

    /// <summary>Stereo balance: -1 = left only, 0 = center, 1 = right only.</summary>
    public float Balance
    {
        get => _balance;
        set => _balance = Math.Clamp(value, -1f, 1f);
    }

    // Q of ~1.4 gives each band a moderately wide bell so adjacent
    // one-octave-spaced bands overlap smoothly (matching how the curve
    // looks in the UI) rather than each acting like a narrow notch.
    private BiQuadFilter MakeFilter(int band, float gainDb) =>
        BiQuadFilter.PeakingEQ(WaveFormat.SampleRate, (float)BandFrequencies[band], 1.4f, gainDb);

    public int Read(float[] buffer, int offset, int count)
    {
        // Read straight into the caller's buffer instead of a fixed-size
        // scratch buffer. A previous version of this method used a fixed
        // 8192-float scratch buffer and silently clamped `count` to that
        // size — but WasapiOut can request more than that per call (its
        // internal buffer size scales with latency and sample rate), and
        // ISampleProvider.Read returning less than the requested `count`
        // mid-stream is exactly the signal NAudio treats as "end of
        // stream". That bug made every track appear to end after roughly
        // its first ~100ms of audio. Reading directly into the full
        // requested range removes the size mismatch entirely.
        int samplesRead = _source.Read(buffer, offset, count);

        // Balance gains: equal-power-ish simple linear pan, cheap and
        // adequate for a "nudge left/right" control rather than a
        // professional panner.
        float leftGain = _balance <= 0 ? 1f : 1f - _balance;
        float rightGain = _balance >= 0 ? 1f : 1f + _balance;

        for (int i = 0; i < samplesRead; i += 2)
        {
            float left = buffer[offset + i];
            float right = (i + 1 < samplesRead) ? buffer[offset + i + 1] : left;

            for (int band = 0; band < BandCount; band++)
            {
                left = _filters[band, 0].Transform(left);
                right = _filters[band, 1].Transform(right);
            }

            buffer[offset + i] = left * leftGain;
            if (i + 1 < samplesRead) buffer[offset + i + 1] = right * rightGain;
        }

        return samplesRead;
    }
}
