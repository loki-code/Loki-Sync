using System;
using System.Globalization;
using System.Windows.Data;

namespace LokiSync.Converters;

/// <summary>Formats an EQ gain (float, dB) as "+6 dB" / "-3 dB" / "0 dB" for slider tooltips and readouts.</summary>
public sealed class DbLabelConverter : IValueConverter
{
    public static readonly DbLabelConverter Instance = new();

    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        double db = value switch
        {
            float f => f,
            double d => d,
            _ => 0
        };

        return db switch
        {
            > 0 => $"+{db:0.#} dB",
            < 0 => $"{db:0.#} dB",
            _ => "0 dB"
        };
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}
