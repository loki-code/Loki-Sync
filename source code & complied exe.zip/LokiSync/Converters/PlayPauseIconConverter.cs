using System;
using System.Globalization;
using System.Windows.Data;

namespace LokiSync.Converters;

/// <summary>
/// True (playing) → Segoe MDL2 Assets pause glyph, false/other (paused or
/// nothing loaded) → play glyph. Shared by the transport bar's big
/// play/pause button and every per-row play button in the Library/playlist
/// lists, so all of them show a glyph that's actually correct for their
/// bound track's state instead of a button that always reads "play" no
/// matter what's playing.
/// Uses the same Segoe MDL2 Assets icon font as the rest of the app
/// (cover-art placeholder, "fully tagged" checkmark, etc.) instead of
/// emoji, so every glyph in the UI renders at a consistent weight/size.
/// </summary>
public sealed class PlayPauseIconConverter : IValueConverter
{
    public static readonly PlayPauseIconConverter Instance = new();

    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        value is true ? "\uE769" : "\uE768";

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}
