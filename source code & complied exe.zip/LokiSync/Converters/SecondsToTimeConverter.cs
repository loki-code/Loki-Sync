using System;
using System.Globalization;
using System.Windows.Data;

namespace LokiSync.Converters;

public sealed class SecondsToTimeConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        double seconds = value is double d ? d : 0;
        if (double.IsNaN(seconds) || seconds < 0) seconds = 0;

        var ts = TimeSpan.FromSeconds(seconds);
        return ts.Hours > 0 ? ts.ToString(@"h\:mm\:ss") : ts.ToString(@"m\:ss");
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}
