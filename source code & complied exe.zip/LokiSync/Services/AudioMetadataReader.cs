using System;
using System.IO;
using LokiSync.Models;

namespace LokiSync.Services;

/// <summary>
/// Extracts basic metadata from local audio files.
/// Reads ID3v2 (MP3) tags directly from the file bytes — no external
/// libraries, no network lookups (e.g. no MusicBrainz/last.fm calls).
/// Falls back to the file name when tags are absent or unreadable.
/// Duration is left at TimeSpan.Zero here and filled in lazily by the
/// player when the file is actually opened (MediaPlayer reports it then).
/// </summary>
public static class AudioMetadataReader
{
    public static readonly string[] SupportedExtensions =
    {
        ".mp3", ".wav", ".wma", ".m4a", ".flac", ".aac", ".ogg"
    };

    public static Track ReadTrack(string filePath)
    {
        var track = new Track { FilePath = filePath };

        try
        {
            if (string.Equals(Path.GetExtension(filePath), ".mp3", StringComparison.OrdinalIgnoreCase))
            {
                TryReadId3V2(filePath, track);
            }
        }
        catch
        {
            // Corrupt/unreadable tags should never crash a library scan.
            // We simply fall back to the file name (see Track.DisplayTitle).
        }

        return track;
    }

    private static void TryReadId3V2(string filePath, Track track)
    {
        using var fs = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read);
        Span<byte> header = stackalloc byte[10];
        if (fs.Read(header) != 10) return;
        if (header[0] != 'I' || header[1] != 'D' || header[2] != '3') return;

        int tagSize = SyncSafeToInt(header[6], header[7], header[8], header[9]);
        if (tagSize <= 0 || tagSize > fs.Length) return;

        var tagBytes = new byte[tagSize];
        int read = fs.Read(tagBytes, 0, tagSize);
        if (read != tagSize) return;

        int pos = 0;
        while (pos + 10 <= tagBytes.Length)
        {
            string frameId = System.Text.Encoding.ASCII.GetString(tagBytes, pos, 4);
            if (frameId == "\0\0\0\0") break;

            int frameSize = (tagBytes[pos + 4] << 24) | (tagBytes[pos + 5] << 16) |
                             (tagBytes[pos + 6] << 8) | tagBytes[pos + 7];
            if (frameSize <= 0 || pos + 10 + frameSize > tagBytes.Length) break;

            int contentStart = pos + 10;

            switch (frameId)
            {
                case "TIT2":
                    track.Title = DecodeFrame(tagBytes, contentStart, frameSize);
                    break;
                case "TPE1":
                    track.Artist = DecodeFrame(tagBytes, contentStart, frameSize);
                    break;
                case "TALB":
                    track.Album = DecodeFrame(tagBytes, contentStart, frameSize);
                    break;
            }

            pos += 10 + frameSize;
        }
    }

    private static int SyncSafeToInt(byte b1, byte b2, byte b3, byte b4) =>
        (b1 << 21) | (b2 << 14) | (b3 << 7) | b4;

    private static string DecodeFrame(byte[] data, int start, int length)
    {
        if (length <= 1) return string.Empty;

        byte encodingByte = data[start];
        int textStart = start + 1;
        int textLength = length - 1;

        var text = encodingByte switch
        {
            1 => System.Text.Encoding.Unicode.GetString(data, textStart, textLength),
            2 => System.Text.Encoding.BigEndianUnicode.GetString(data, textStart, textLength),
            3 => System.Text.Encoding.UTF8.GetString(data, textStart, textLength),
            _ => System.Text.Encoding.Latin1.GetString(data, textStart, textLength)
        };

        return text.Trim('\0', ' ');
    }
}
