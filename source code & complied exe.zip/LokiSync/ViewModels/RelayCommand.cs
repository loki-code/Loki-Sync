using System;
using System.Threading.Tasks;
using System.Windows.Input;

namespace LokiSync.ViewModels;

/// <summary>
/// Minimal ICommand implementation. Avoids pulling in a full MVVM
/// framework/NuGet dependency to keep the app lightweight.
///
/// Uses one constructor (parameter-aware) plus a static factory for the
/// no-parameter case, rather than two overloaded constructors. A method
/// group like "TogglePlayPause" is implicitly convertible to both
/// Action and Action&lt;object?&gt;, which previously let the compiler pick
/// the wrong constructor overload and then fail trying to bind a
/// Func&lt;bool&gt; canExecute to a Predicate&lt;object?&gt; parameter (CS1593).
/// The named factory method removes that ambiguity entirely.
/// </summary>
public sealed class RelayCommand : ICommand
{
    private readonly Action<object?> _execute;
    private readonly Predicate<object?>? _canExecute;
    private bool _isExecuting;

    /// <summary>Command whose execute/canExecute need the command parameter.</summary>
    public RelayCommand(Action<object?> execute, Predicate<object?>? canExecute = null)
    {
        _execute = execute ?? throw new ArgumentNullException(nameof(execute));
        _canExecute = canExecute;
    }

    /// <summary>Command whose execute/canExecute ignore the command parameter.</summary>
    public static RelayCommand Create(Action execute, Func<bool>? canExecute = null)
    {
        ArgumentNullException.ThrowIfNull(execute);
        return new RelayCommand(_ => execute(), canExecute is null ? null : _ => canExecute());
    }

    /// <summary>
    /// Command for an async handler (e.g. RescanCommand). Passing an async
    /// lambda straight into Create(Action, ...) silently compiles to
    /// async void — legal C#, but async void swallows the fact that the
    /// method is still running: CommandManager's requery can fire again
    /// before the previous run's await chain resumes, and on WPF that can
    /// leave the command looking clickable while its actual continuation
    /// never gets back to the UI thread the way a real awaited Task would.
    /// This overload keeps the delegate as Func&lt;Task&gt; end-to-end (no
    /// async-void conversion at all) and guards re-entrancy explicitly, so
    /// a second click while one run is still in flight is a deliberate
    /// no-op instead of an accident of timing.
    /// </summary>
    public static RelayCommand CreateAsync(Func<Task> executeAsync, Func<bool>? canExecute = null)
    {
        ArgumentNullException.ThrowIfNull(executeAsync);
        RelayCommand? command = null;
        command = new RelayCommand(
            async _ =>
            {
                if (command!._isExecuting) return;
                command._isExecuting = true;
                command.RaiseCanExecuteChanged();
                try
                {
                    await executeAsync();
                }
                finally
                {
                    command._isExecuting = false;
                    command.RaiseCanExecuteChanged();
                }
            },
            canExecute is null ? null : _ => !command!._isExecuting && canExecute());
        return command;
    }

    public bool CanExecute(object? parameter) => _canExecute?.Invoke(parameter) ?? true;

    public void Execute(object? parameter) => _execute(parameter);

    public event EventHandler? CanExecuteChanged;

    public void RaiseCanExecuteChanged() => CanExecuteChanged?.Invoke(this, EventArgs.Empty);
}
