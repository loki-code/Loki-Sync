using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using LokiSync.Models;

namespace LokiSync.Services;

/// <summary>
/// Walks user-selected local folders on disk and builds Track entries for
/// every supported audio file found. Pure local filesystem enumeration —
/// no network access of any kind.
/// </summary>
public sealed class LibraryScanService
{
    public async Task<List<Track>> ScanFoldersAsync(
        IEnumerable<string> folders,
        CancellationToken cancellationToken = default)
    {
        return await Task.Run(() =>
        {
            var tracks = new List<Track>();
            var seenPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (var folder in folders)
            {
                cancellationToken.ThrowIfCancellationRequested();
                if (!Directory.Exists(folder)) continue;

                // Directory.EnumerateFiles is lazy: it doesn't touch the disk
                // (and can't throw) until it's actually iterated. Wrapping
                // just the call that builds the iterator in try/catch did
                // nothing — the exception it was meant to catch is thrown
                // later, inside the foreach below, once enumeration actually
                // walks into a restricted subfolder (e.g. "System Volume
                // Information" on a drive root). That escaped uncaught,
                // which either aborted the whole scan for every folder after
                // it or - since ScanFoldersAsync runs inside Task.Run and is
                // awaited - surfaced as "Scan failed" with nothing added to
                // the library. The fix is to catch around the enumeration
                // itself, per file, so one inaccessible subfolder can't take
                // out the rest of the scan.
                IEnumerable<string> files;
                try
                {
                    files = Directory.EnumerateFiles(folder, "*.*", SearchOption.AllDirectories);
                }
                catch (UnauthorizedAccessException ex)
                {
                    AppLog.Warn($"Skipped watched folder (access denied): {folder} — {ex.Message}");
                    continue;
                }

                using var enumerator = files.GetEnumerator();
                while (true)
                {
                    cancellationToken.ThrowIfCancellationRequested();

                    string file;
                    try
                    {
                        if (!enumerator.MoveNext()) break;
                        file = enumerator.Current;
                    }
                    catch (UnauthorizedAccessException ex)
                    {
                        // Hit a restricted subfolder mid-walk. Enumerator is
                        // now unusable, but everything found before this
                        // point is kept; move on to the next watched folder.
                        AppLog.Warn($"Stopped enumerating '{folder}' early (access denied partway through): {ex.Message}");
                        break;
                    }

                    if (!AudioMetadataReader.SupportedExtensions
                            .Contains(Path.GetExtension(file), StringComparer.OrdinalIgnoreCase))
                        continue;

                    if (!seenPaths.Add(file)) continue;

                    tracks.Add(AudioMetadataReader.ReadTrack(file));
                }
            }

            return tracks
                .OrderBy(t => t.Artist, StringComparer.OrdinalIgnoreCase)
                .ThenBy(t => t.Album, StringComparer.OrdinalIgnoreCase)
                .ThenBy(t => t.DisplayTitle, StringComparer.OrdinalIgnoreCase)
                .ToList();
        }, cancellationToken);
    }
}
