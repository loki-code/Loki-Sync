using System;
using System.ComponentModel;

namespace LokiSync.Models;

/// <summary>
/// Represents a single local audio file and its (locally read) metadata.
/// No data here ever leaves the machine.
/// </summary>
public sealed class Track : INotifyPropertyChanged
{
    public required string FilePath { get; init; }

    public string Title { get; set; } = string.Empty;

    private string _artist = string.Empty;
    /// <summary>
    /// Artist/author name. Settable after the fact (either read from ID3
    /// tags at scan time, or typed in manually by the user via the track
    /// row) — raises PropertyChanged so DisplayTitle-adjacent bindings and
    /// IsMetadataComplete/the row's checkmark update live as soon as it's
    /// edited, without needing a rescan.
    /// </summary>
    public string Artist
    {
        get => _artist;
        set
        {
            if (_artist == value) return;
            _artist = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Artist)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsMetadataComplete)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SubtitleDisplay)));
        }
    }

    public string Album { get; set; } = string.Empty;
    public TimeSpan Duration { get; set; }

    private string? _coverArtPath;
    /// <summary>
    /// Local file path to this track's cover/icon image, or null if none
    /// has been set. User-picked icons are copied into
    /// %AppData%\LokiSync\covers\ (see LibraryStorageService) so the
    /// original file the user picked can move or be deleted without
    /// breaking the track's icon.
    /// </summary>
    public string? CoverArtPath
    {
        get => _coverArtPath;
        set
        {
            if (_coverArtPath == value) return;
            _coverArtPath = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CoverArtPath)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HasCoverArt)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsMetadataComplete)));
        }
    }

    public bool HasCoverArt => !string.IsNullOrWhiteSpace(CoverArtPath);

    /// <summary>
    /// True once both an artist/author name and a cover icon are present.
    /// Drives the green checkmark badge on the track row — the "this one's
    /// fully tagged" signal.
    /// </summary>
    public bool IsMetadataComplete => !string.IsNullOrWhiteSpace(Artist) && HasCoverArt;

    private bool _isNowPlaying;
    /// <summary>
    /// True for the single track currently loaded in the player — playing
    /// OR paused. Set by MainViewModel whenever NowPlaying changes; exists
    /// purely so the UI can highlight the active row (background tint, the
    /// small accent dot) in any list this track appears in without a
    /// separate lookup/converter per row.
    /// </summary>
    public bool IsNowPlaying
    {
        get => _isNowPlaying;
        set
        {
            if (_isNowPlaying == value) return;
            _isNowPlaying = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsNowPlaying)));
        }
    }

    private bool _isActivelyPlaying;
    /// <summary>
    /// True only while THIS track is both the loaded track AND transport is
    /// actually playing (not paused). Distinct from IsNowPlaying so a
    /// row's play button can show a pause glyph while sound is coming out
    /// and a play glyph the instant it's paused, instead of a glyph that's
    /// only ever accurate for "is this the loaded track" and stays wrong
    /// (stuck on pause-icon) after the user hits pause.
    /// </summary>
    public bool IsActivelyPlaying
    {
        get => _isActivelyPlaying;
        set
        {
            if (_isActivelyPlaying == value) return;
            _isActivelyPlaying = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsActivelyPlaying)));
        }
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    public string FileName => System.IO.Path.GetFileNameWithoutExtension(FilePath);

    public string DisplayTitle => string.IsNullOrWhiteSpace(Title) ? FileName : Title;

    /// <summary>
    /// "Artist — Album" for display (e.g. the Now Playing hero panel), with
    /// the " — " separator only present when both sides actually have
    /// something to show. Plain "{Binding Artist} — {Binding Album}" text in
    /// XAML would leave a dangling "Artist — " for the very common case of
    /// scanned files with no Album tag, since Album defaults to "".
    /// </summary>
    public string SubtitleDisplay
    {
        get
        {
            bool hasArtist = !string.IsNullOrWhiteSpace(Artist);
            bool hasAlbum = !string.IsNullOrWhiteSpace(Album);
            if (hasArtist && hasAlbum) return $"{Artist} — {Album}";
            if (hasArtist) return Artist;
            if (hasAlbum) return Album;
            return "Unknown artist";
        }
    }

    public string DurationDisplay => Duration == TimeSpan.Zero
        ? "--:--"
        : Duration.Hours > 0
            ? Duration.ToString(@"h\:mm\:ss")
            : Duration.ToString(@"m\:ss");

    public override string ToString() => DisplayTitle;

    public override bool Equals(object? obj) =>
        obj is Track other && string.Equals(FilePath, other.FilePath, StringComparison.OrdinalIgnoreCase);

    public override int GetHashCode() => FilePath.ToLowerInvariant().GetHashCode();
}

/// <summary>
/// Carries a track row's just-typed author name up to SetTrackArtistCommand.
/// The row's TextBox binds Artist as OneWay (so external renames/rescans
/// can still update it while the user isn't actively editing), which means
/// the VM can't just read Track.Artist back — the new text has to be
/// passed along explicitly instead.
/// </summary>
public sealed record TrackArtistEdit(Track Track, string Artist);
