using System;
using System.Windows.Threading;
using LokiSync.Audio;
using NAudio.Wave;
using NAudio.Wave.SampleProviders;

namespace LokiSync.Services;

public enum RepeatMode
{
    Off,
    RepeatOne,
    RepeatAll
}

/// <summary>
/// Local audio file playback backed by NAudio. Replaces the previous
/// WPF MediaPlayer implementation because MediaPlayer has no hook point
/// for audio processing — there's no way to insert an EQ into its
/// pipeline. NAudio exposes the raw sample stream, so a real bass/mid/
/// treble equalizer (see EqualizerSampleProvider) can sit between the file
/// reader and the output device. Still fully local: reads a file from
/// disk, writes to the local sound device — no network I/O anywhere.
/// </summary>
public sealed class PlaybackService : IDisposable
{
    private AudioFileReader? _fileReader;
    private WasapiOut? _output;
    private EqualizerSampleProvider? _equalizer;
    private readonly DispatcherTimer _positionTimer;

    private bool _isPlaying;
    private string? _currentPath;
    private double _volume = 1.0;
    private readonly float[] _bandGainsDb = new float[EqualizerSampleProvider.BandCount];
    private float _balance;

    public event EventHandler? TrackEnded;
    public event EventHandler? PositionChanged;
    public event EventHandler<Exception>? PlaybackFailed;

    public PlaybackService()
    {
        _positionTimer = new DispatcherTimer
        {
            Interval = TimeSpan.FromMilliseconds(250)
        };
        _positionTimer.Tick += (_, _) => PositionChanged?.Invoke(this, EventArgs.Empty);
    }

    public bool IsPlaying => _isPlaying;
    public string? CurrentPath => _currentPath;

    public TimeSpan Position
    {
        get => _fileReader?.CurrentTime ?? TimeSpan.Zero;
        set
        {
            if (_fileReader is null) return;
            // Clamp so a seek-bar drag past either end (easy to do while
            // dragging fast) doesn't throw ArgumentOutOfRangeException from
            // the underlying reader.
            var clamped = TimeSpan.FromSeconds(
                Math.Clamp(value.TotalSeconds, 0, Math.Max(0, _fileReader.TotalTime.TotalSeconds)));
            _fileReader.CurrentTime = clamped;
        }
    }

    public TimeSpan? NaturalDuration => _fileReader?.TotalTime;

    public double Volume
    {
        get => _volume;
        set
        {
            _volume = Math.Clamp(value, 0.0, 1.0);
            if (_fileReader is not null) _fileReader.Volume = (float)_volume;
        }
    }

    public bool IsMuted { get; set; }

    /// <summary>Number of graphic EQ bands. Mirrors EqualizerSampleProvider.BandCount.</summary>
    public static int BandCount => EqualizerSampleProvider.BandCount;

    /// <summary>Center frequencies (Hz) for each band, low to high.</summary>
    public static double[] BandFrequencies => EqualizerSampleProvider.BandFrequencies;

    /// <summary>Gets the last-set gain (dB, -12..+12) for a band.</summary>
    public float GetBandGainDb(int band) => _bandGainsDb[band];

    /// <summary>Sets the gain (dB, -12..+12) for a single graphic EQ band. Persisted and reapplied to every new track.</summary>
    public void SetBandGainDb(int band, float gainDb)
    {
        if (band < 0 || band >= _bandGainsDb.Length) return;
        _bandGainsDb[band] = gainDb;
        _equalizer?.SetBandGainDb(band, gainDb);
    }

    /// <summary>Stereo balance -1 (left) .. 0 (center) .. 1 (right).</summary>
    public float Balance
    {
        get => _balance;
        set
        {
            _balance = value;
            if (_equalizer is not null) _equalizer.Balance = value;
        }
    }

    public void Load(string filePath)
    {
        TearDownCurrentTrack(disposeSynchronously: false);
        _currentPath = filePath;
        _fileReader = new AudioFileReader(filePath) { Volume = (float)_volume };

        // AudioFileReader always exposes stereo-or-mono float samples via
        // ISampleProvider; EqualizerSampleProvider requires stereo, so a
        // mono file (common for voice/podcast-style recordings, less so
        // for music, but still worth not crashing on) is upmixed first.
        ISampleProvider stereoSource = _fileReader.WaveFormat.Channels == 1
            ? new MonoToStereoSampleProvider(_fileReader)
            : _fileReader;

        _equalizer = new EqualizerSampleProvider(stereoSource)
        {
            Balance = _balance
        };
        for (int band = 0; band < _bandGainsDb.Length; band++)
            _equalizer.SetBandGainDb(band, _bandGainsDb[band]);

        _output = new WasapiOut(NAudio.CoreAudioApi.AudioClientShareMode.Shared, 100);
        _output.PlaybackStopped += OnPlaybackStopped;
        _output.Init(_equalizer);
    }

    public void Play()
    {
        _output?.Play();
        _isPlaying = true;
        _positionTimer.Start();
    }

    public void Pause()
    {
        _output?.Pause();
        _isPlaying = false;
        _positionTimer.Stop();
    }

    /// <summary>
    /// User-visible stop (e.g. reaching the end of a non-repeating,
    /// non-shuffled queue) — unlike TearDownCurrentTrack, the device and
    /// file stay alive and reusable afterward, so a later Play() can
    /// resume without reloading. Calling _output.Stop() itself raises
    /// PlaybackStopped just like a natural end-of-file does; if that were
    /// left to reach OnPlaybackStopped it would raise TrackEnded a second
    /// time for the very call that already told the caller playback
    /// ended — e.g. PlayNext() calling Stop() at the end of the queue
    /// would recursively call itself via TrackEnded → OnTrackEnded →
    /// PlayNext(). Swapping the handler out for a no-op for this one
    /// Stop() call (then restoring it) prevents that without needing a
    /// shared "ignore the next event" flag that could get out of sync.
    /// </summary>
    public void Stop()
    {
        _isPlaying = false;
        _positionTimer.Stop();

        if (_output is null) return;

        var output = _output;
        output.PlaybackStopped -= OnPlaybackStopped;
        output.PlaybackStopped += RestoreHandlerAfterManualStop;
        output.Stop();

        void RestoreHandlerAfterManualStop(object? s, StoppedEventArgs e)
        {
            output.PlaybackStopped -= RestoreHandlerAfterManualStop;
            // Only reattach if this is still the live output — Load() may
            // have already swapped it out and started tearing this one
            // down while the Stop() above was still in flight.
            if (ReferenceEquals(output, _output))
                output.PlaybackStopped += OnPlaybackStopped;
        }
    }

    /// <summary>
    /// Fires when WasapiOut's playback actually stops. WasapiOut captures
    /// the SynchronizationContext it was constructed on (here, the UI
    /// thread — PlaybackService is built from MainViewModel's constructor)
    /// and posts this event back onto it automatically, so — unlike some
    /// other NAudio backends — this handler already runs on the UI thread;
    /// no manual Dispatcher.Invoke is needed here.
    ///
    /// Checking `sender == _output` (rather than a shared "are we tearing
    /// down" flag) is what tells apart two cases that both raise this
    /// event, and stays correct even if a second Load() starts a new
    /// teardown before an earlier one has finished disposing:
    ///   1) sender is _output's CURRENT value — the live track's Read()
    ///      returned 0 on its own, i.e. it actually reached its end.
    ///      That's the only case that should raise TrackEnded.
    ///   2) sender is a previous, already-replaced output being torn down
    ///      (its own dedicated handler in TearDownCurrentTrack disposes
    ///      it) — this generic handler must ignore it, or switching
    ///      tracks would recursively trigger "play next" on top of
    ///      whatever explicitly requested the new track.
    /// </summary>
    private void OnPlaybackStopped(object? sender, StoppedEventArgs e)
    {
        if (!ReferenceEquals(sender, _output)) return;

        if (e.Exception is not null)
        {
            _positionTimer.Stop();
            _isPlaying = false;
            PlaybackFailed?.Invoke(this, e.Exception);
            return;
        }

        _positionTimer.Stop();
        _isPlaying = false;
        TrackEnded?.Invoke(this, EventArgs.Empty);
    }

    /// <summary>
    /// Tears down the current output device and file reader. NAudio's own
    /// guidance is explicit: Stop() only signals WasapiOut's internal
    /// thread to stop; it does not block until that thread has exited, so
    /// disposing immediately after Stop() (the previous version of this
    /// method did exactly that) races that thread. The correct fix is
    /// *not* to block-wait for PlaybackStopped either — WasapiOut delivers
    /// that event via the UI thread's own SynchronizationContext, so a
    /// synchronous wait from the UI thread would deadlock waiting for the
    /// very thread it's blocking. Instead, disposal is deferred to a
    /// dedicated PlaybackStopped handler on the *old* output, which is
    /// guaranteed to fire (NAudio always raises it, including for an
    /// explicit Stop()) without ever blocking the caller — and which is
    /// self-contained per call, so overlapping teardowns from rapid track
    /// switches can never interfere with each other.
    /// </summary>
    /// <param name="disposeSynchronously">
    /// True only from Dispose() (app shutdown), where blocking briefly is
    /// acceptable and necessary — there's no later event loop turn left
    /// for an async continuation to run on.
    /// </param>
    private void TearDownCurrentTrack(bool disposeSynchronously)
    {
        var outputToDispose = _output;
        var readerToDispose = _fileReader;
        _output = null;
        _fileReader = null;
        _equalizer = null;
        _isPlaying = false;

        if (outputToDispose is null)
        {
            readerToDispose?.Dispose();
            return;
        }

        // This output is no longer the live one (we just nulled _output
        // above), so its own PlaybackStopped firing from here on must
        // never reach the generic OnPlaybackStopped handler — that handler
        // already re-checks `sender == _output` itself, but detaching here
        // too keeps exactly one handler (the disposal one below) driving
        // what happens to this specific instance.
        outputToDispose.PlaybackStopped -= OnPlaybackStopped;

        if (disposeSynchronously)
        {
            using var stoppedSignal = new System.Threading.ManualResetEventSlim(false);
            void OnStopped(object? s, StoppedEventArgs e) => stoppedSignal.Set();

            outputToDispose.PlaybackStopped += OnStopped;
            try
            {
                outputToDispose.Stop();
                // Bounded wait: this only runs from Dispose() during app
                // shutdown, where the WPF message loop may already be
                // winding down and might not pump the SynchronizationContext
                // post reliably — a timeout here means "give up and dispose
                // anyway" rather than risk hanging process exit.
                stoppedSignal.Wait(TimeSpan.FromSeconds(2));
            }
            finally
            {
                outputToDispose.PlaybackStopped -= OnStopped;
            }

            outputToDispose.Dispose();
            readerToDispose?.Dispose();
        }
        else
        {
            void OnStoppedForDisposal(object? s, StoppedEventArgs e)
            {
                outputToDispose.PlaybackStopped -= OnStoppedForDisposal;
                outputToDispose.Dispose();
                readerToDispose?.Dispose();
            }

            outputToDispose.PlaybackStopped += OnStoppedForDisposal;
            outputToDispose.Stop();
        }
    }

    public void Dispose()
    {
        // DispatcherTimer is thread-affine to whoever created it (the UI
        // thread) — Stop() must run there even if Dispose() itself is now
        // being called from a background thread (see MainWindow_Closing,
        // which offloads disposal so the close button doesn't freeze the
        // window for the ~2s bounded wait below).
        if (_positionTimer.Dispatcher.CheckAccess())
            _positionTimer.Stop();
        else
            _positionTimer.Dispatcher.Invoke(_positionTimer.Stop);

        TearDownCurrentTrack(disposeSynchronously: true);
    }
}
