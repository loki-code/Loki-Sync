using System;
using System.Globalization;
using System.Windows.Data;

namespace LokiSync.Converters;

/// <summary>
/// True (EQ active) -&gt; fully opaque, False (bypassed) -&gt; dimmed. Used on
/// EqCurveControl so the graphic-EQ plot visually reads as "not currently
/// doing anything" while EqEnabled is off, matching the curve's own
/// IsEnabled (which also disables dragging the dots during bypass) rather
/// than leaving a fully bright, seemingly-live curve that isn't actually
/// affecting the sound.
/// </summary>
public sealed class EqEnabledOpacityConverter : IValueConverter
{
    public static readonly EqEnabledOpacityConverter Instance = new();

    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        value is true ? 1.0 : 0.45;

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}
