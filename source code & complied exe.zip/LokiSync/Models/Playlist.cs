using System;
using System.Collections.Generic;

namespace LokiSync.Models;

/// <summary>
/// A named, ordered collection of track file paths.
/// Persisted locally as JSON — see LibraryStorageService.
/// </summary>
public sealed class Playlist
{
    public string Id { get; init; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "New Playlist";

    /// <summary>File paths of tracks in this playlist, in order.</summary>
    public List<string> TrackPaths { get; init; } = new();

    public DateTime CreatedUtc { get; init; } = DateTime.UtcNow;
}
