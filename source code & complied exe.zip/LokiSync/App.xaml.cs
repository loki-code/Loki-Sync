using System;
using System.Threading;
using System.Windows;
using System.Windows.Threading;
using LokiSync.Services;

namespace LokiSync;

/// <summary>
/// LokiSync entry point. The app performs no network initialization —
/// it only loads local state from %AppData%\LokiSync on startup.
/// </summary>
public partial class App : Application
{
    // Guards against re-entrancy: Shutdown() itself triggers another
    // layout/render pass while tearing the window down, which can throw
    // the *same* underlying exception again and re-enter this handler.
    // Without this flag, one real crash (e.g. a bad BorderBrush value
    // that fails during every Arrange pass) fires this handler dozens of
    // times before the process actually exits — each one showing another
    // message box and writing another duplicate stack trace to the log.
    // The first occurrence is the one that matters; every subsequent one
    // is pure noise from the same root cause. Backed by an int (not a
    // plain bool) and flipped via Interlocked.Exchange because
    // DispatcherUnhandledException fires on the UI thread while
    // AppDomain.UnhandledException can fire from any thread — a plain
    // bool read-then-write from two different threads at once is a real
    // (if narrow) race that Interlocked closes.
    private int _isHandlingFatalException;

    protected override void OnStartup(StartupEventArgs e)
    {
        // Without this handler, any exception thrown during startup (e.g. in
        // MainWindow's constructor/InitializeComponent or MainViewModel's
        // constructor) unwinds past WPF's dispatcher and the process exits
        // silently — no window, no error, nothing. That produces exactly the
        // "I ran the exe and nothing showed up" symptom with no way to
        // diagnose it. Surface it instead.
        DispatcherUnhandledException += OnDispatcherUnhandledException;
        AppDomain.CurrentDomain.UnhandledException += OnAppDomainUnhandledException;

        AppLog.Info("LokiSync starting up.");
        Exit += (_, _) => AppLog.Info("LokiSync exiting normally.");

        base.OnStartup(e);
    }

    private void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        // Always mark handled and let WPF proceed as if we dealt with it —
        // returning without doing so would let the exception propagate
        // and crash the process anyway. But only log/show the dialog/call
        // Shutdown once; subsequent re-entries during that same shutdown
        // are swallowed silently.
        e.Handled = true;
        if (Interlocked.Exchange(ref _isHandlingFatalException, 1) == 1) return;

        AppLog.Error("Unhandled dispatcher exception.", e.Exception);
        MessageBox.Show(
            $"LokiSync hit an unexpected error and needs to close:\n\n{e.Exception}",
            "LokiSync — Unexpected Error",
            MessageBoxButton.OK,
            MessageBoxImage.Error);
        Shutdown(-1);
    }

    private void OnAppDomainUnhandledException(object sender, UnhandledExceptionEventArgs e)
    {
        if (Interlocked.Exchange(ref _isHandlingFatalException, 1) == 1) return;

        if (e.ExceptionObject is Exception ex)
        {
            AppLog.Error("Unhandled AppDomain exception (fatal).", ex);
            MessageBox.Show(
                $"LokiSync hit a fatal error and needs to close:\n\n{ex}",
                "LokiSync — Fatal Error",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
        }
    }
}
