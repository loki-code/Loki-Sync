using System;
using System.Globalization;
using System.Windows.Data;

namespace LokiSync.Converters;

public sealed class PlayPauseTextConverter : IValueConverter
{
    public static readonly PlayPauseTextConverter Instance = new();

    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        value is true ? "Pause" : "Play";

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}
