using System;
using System.Collections.Specialized;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using LokiSync.ViewModels;

namespace LokiSync.Views.Controls;

/// <summary>
/// Graphic-EQ curve: a log-frequency-axis grid with one draggable dot per
/// band, connected by a smooth spline, roughly matching a conventional
/// "spectrum + curve" equalizer UI. Bands is set (via binding, from
/// MainViewModel.EqBands) and the control lays out one Thumb per band,
/// repositioning them whenever the panel resizes or a gain changes
/// elsewhere (e.g. Reset or a preset load) so the dots and slider list
/// (if both are visible) always agree.
///
/// Deliberately built by hand with a Canvas + Thumbs rather than a
/// third-party charting control — the interaction (drag a point, see the
/// curve reflow live) is simple enough that owning the ~150 lines here
/// avoids a new dependency for one screen.
/// </summary>
public partial class EqCurveControl : UserControl
{
    public static readonly DependencyProperty BandsProperty = DependencyProperty.Register(
        nameof(Bands), typeof(System.Collections.ObjectModel.ObservableCollection<EqBandViewModel>),
        typeof(EqCurveControl), new PropertyMetadata(null, OnBandsChanged));

    public System.Collections.ObjectModel.ObservableCollection<EqBandViewModel>? Bands
    {
        get => (System.Collections.ObjectModel.ObservableCollection<EqBandViewModel>?)GetValue(BandsProperty);
        set => SetValue(BandsProperty, value);
    }

    private static void OnBandsChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        var control = (EqCurveControl)d;

        if (e.OldValue is INotifyCollectionChanged oldNotify)
            oldNotify.CollectionChanged -= control.OnBandsCollectionChanged;
        if (e.NewValue is INotifyCollectionChanged newNotify)
            newNotify.CollectionChanged += control.OnBandsCollectionChanged;

        // Detach from the OLD collection's items before RebuildDots (which
        // reads the DP's current value, i.e. the NEW collection) runs --
        // otherwise a rebind would try to unsubscribe from the wrong bands.
        control.DetachBandHandlers(e.OldValue as System.Collections.Generic.IReadOnlyList<EqBandViewModel>);
        control.RebuildDots();
    }

    private void OnBandsCollectionChanged(object? sender, NotifyCollectionChangedEventArgs e) => RebuildDots();

    private readonly System.Collections.Generic.List<Thumb> _dots = new();

    // Paired 1:1 with _dots (and with Bands, while dots are current) so
    // RebuildDots can unsubscribe each band's PropertyChanged handler
    // before tearing the dots down and resubscribing fresh ones. Without
    // this, every rebuild left the previous handlers attached to the
    // (long-lived, mutated-in-place) EqBandViewModel instances forever --
    // an accumulating leak on any re-run, not just growing call fanout
    // but also pinning old EqCurveControl instances alive.
    private readonly System.Collections.Generic.List<System.ComponentModel.PropertyChangedEventHandler> _bandHandlers = new();

    public EqCurveControl()
    {
        InitializeComponent();
        Loaded += (_, _) => { DrawGrid(); RebuildDots(); };
        SizeChanged += (_, _) => { DrawGrid(); LayoutDots(); DrawCurve(); };
    }

    /// <summary>Rebuilds one Thumb per band from scratch — called on first load and whenever the Bands collection itself changes (not on a gain change; that's handled by re-binding each existing dot's Y).</summary>
    private void RebuildDots()
    {
        // Bands can be assigned (via the "{Binding EqBands}" markup) before
        // InitializeComponent has finished wiring up the named elements
        // below, e.g. while the outer Window is still being constructed.
        // Bail out here; the Loaded handler calls RebuildDots again once
        // the control is actually part of the visual tree.
        if (DotsCanvas is null) return;

        DetachBandHandlers(Bands);
        DotsCanvas.Children.Clear();
        _dots.Clear();

        if (Bands is null) return;

        foreach (var band in Bands)
        {
            var dot = BuildDot(band);
            _dots.Add(dot);
            DotsCanvas.Children.Add(dot);

            // Redraw whenever this band's gain changes for any reason —
            // dragging its own dot, a preset load, or Reset — so the curve
            // and every dot's position always reflect the live gains.
            System.ComponentModel.PropertyChangedEventHandler handler = (_, args) =>
            {
                if (args.PropertyName != nameof(EqBandViewModel.NormalizedGain)) return;
                LayoutDots();
                DrawCurve();
            };
            band.PropertyChanged += handler;
            _bandHandlers.Add(handler);
        }

        LayoutDots();
        DrawCurve();
    }

    /// <summary>Detaches every handler RebuildDots previously attached, matched up positionally against the given collection (the one they were actually attached to -- see call sites for why that isn't always the current Bands value).</summary>
    private void DetachBandHandlers(System.Collections.Generic.IReadOnlyList<EqBandViewModel>? previousBands)
    {
        if (previousBands is not null)
        {
            for (int i = 0; i < _bandHandlers.Count && i < previousBands.Count; i++)
                previousBands[i].PropertyChanged -= _bandHandlers[i];
        }
        _bandHandlers.Clear();
    }

    private Thumb BuildDot(EqBandViewModel band)
    {
        var thumb = new Thumb
        {
            Width = 34,
            Height = 34,
            Cursor = Cursors.SizeNS,
            Tag = band,
            Style = (Style)FindResource("EqDotStyle"),
            ToolTip = band.GainLabel
        };

        thumb.DragDelta += (sender, args) =>
        {
            double height = DotsCanvas.ActualHeight;
            if (height <= 0) return;

            // Dragging up (negative Y delta) should increase gain, so the
            // sign is flipped relative to screen Y. 24 dB span (-12..+12)
            // mapped across the full plot height.
            double deltaDb = -args.VerticalChange / height * 24.0;
            band.GainDb = (float)(band.GainDb + deltaDb);

            if (sender is Thumb t) t.ToolTip = band.GainLabel;
        };

        // Double-click a dot to snap that one band back to 0 dB — a quick
        // per-band reset without reaching for the panel's global Reset.
        thumb.MouseLeftButtonDown += (_, args) =>
        {
            if (args.ClickCount == 2) band.GainDb = 0;
        };

        return thumb;
    }

    private void LayoutDots()
    {
        if (Bands is null) return;
        double width = DotsCanvas.ActualWidth;
        double height = DotsCanvas.ActualHeight;
        if (width <= 0 || height <= 0) return;

        for (int i = 0; i < Bands.Count && i < _dots.Count; i++)
        {
            var (x, y) = PointFor(Bands[i], i, width, height);
            Canvas.SetLeft(_dots[i], x - _dots[i].Width / 2);
            Canvas.SetTop(_dots[i], y - _dots[i].Height / 2);
        }
    }

    /// <summary>Maps a band to plot-space (x, y) pixels. Bands are spaced evenly along X (their frequencies are already roughly log-spaced one octave apart, so even spacing reads correctly as a log axis) and Y follows NormalizedGain.</summary>
    private (double x, double y) PointFor(EqBandViewModel band, int index, double width, double height)
    {
        int count = Bands!.Count;
        double x = count <= 1 ? width / 2 : width * index / (count - 1);
        double y = height * (1 - band.NormalizedGain);
        return (x, y);
    }

    /// <summary>Draws the smooth curve through every band's current point using a cardinal-spline-style Bezier path, plus a soft fill beneath it.</summary>
    private void DrawCurve()
    {
        CurvePath.Data = null;
        FillPath.Data = null;

        if (Bands is null || Bands.Count == 0) return;
        double width = DotsCanvas.ActualWidth;
        double height = DotsCanvas.ActualHeight;
        if (width <= 0 || height <= 0) return;

        var points = new Point[Bands.Count];
        for (int i = 0; i < Bands.Count; i++)
        {
            var (x, y) = PointFor(Bands[i], i, width, height);
            points[i] = new Point(x, y);
        }

        var figure = new PathFigure { StartPoint = points[0], IsClosed = false };
        AddSmoothSegments(figure, points);

        var geometry = new PathGeometry();
        geometry.Figures.Add(figure);
        CurvePath.Data = geometry;

        // Fill geometry: same curve, closed down to the plot's baseline so
        // it reads as an area chart under the line.
        var fillFigure = new PathFigure { StartPoint = points[0], IsClosed = true };
        AddSmoothSegments(fillFigure, points);
        fillFigure.Segments.Add(new LineSegment(new Point(points[^1].X, height), true));
        fillFigure.Segments.Add(new LineSegment(new Point(points[0].X, height), true));

        var fillGeometry = new PathGeometry();
        fillGeometry.Figures.Add(fillFigure);
        FillPath.Data = fillGeometry;
    }

    /// <summary>Catmull-Rom-ish smoothing: converts a point sequence into cubic Bezier segments that pass through every point with continuous tangents, rather than the sharp linear zig-zag a plain PolyLineSegment would give.</summary>
    private static void AddSmoothSegments(PathFigure figure, Point[] points)
    {
        if (points.Length < 2)
        {
            if (points.Length == 1) figure.Segments.Add(new LineSegment(points[0], true));
            return;
        }

        for (int i = 0; i < points.Length - 1; i++)
        {
            Point p0 = i == 0 ? points[i] : points[i - 1];
            Point p1 = points[i];
            Point p2 = points[i + 1];
            Point p3 = i + 2 < points.Length ? points[i + 2] : p2;

            // Standard Catmull-Rom to Bezier control-point conversion.
            var c1 = new Point(
                p1.X + (p2.X - p0.X) / 6.0,
                p1.Y + (p2.Y - p0.Y) / 6.0);
            var c2 = new Point(
                p2.X - (p3.X - p1.X) / 6.0,
                p2.Y - (p3.Y - p1.Y) / 6.0);

            figure.Segments.Add(new BezierSegment(c1, c2, p2, true));
        }
    }

    /// <summary>Draws the static dB gridlines + 0 dB centerline. Frequency labels are separate TextBlocks laid out in XAML below the plot, not drawn here.</summary>
    private void DrawGrid()
    {
        GridCanvas.Children.Clear();
        double width = GridCanvas.ActualWidth;
        double height = GridCanvas.ActualHeight;
        if (width <= 0 || height <= 0) return;

        var gridBrush = (Brush)FindResource("EqGridLineBrush");
        var centerBrush = (Brush)FindResource("EqGridCenterLineBrush");

        // Horizontal lines at +12, +6, 0, -6, -12 dB.
        double[] dbLines = { 12, 6, 0, -6, -12 };
        foreach (double db in dbLines)
        {
            double y = height * (1 - (db + 12) / 24.0);
            var line = new System.Windows.Shapes.Line
            {
                X1 = 0,
                X2 = width,
                Y1 = y,
                Y2 = y,
                Stroke = db == 0 ? centerBrush : gridBrush,
                StrokeThickness = db == 0 ? 1.2 : 1
            };
            GridCanvas.Children.Add(line);
        }
    }
}
