using System;
using System.IO;
using System.Text.Json;
using LokiSync.Models;

namespace LokiSync.Services;

/// <summary>
/// Persists the library/playlist state to a single local JSON file under
/// %AppData%\LokiSync\library.json. This is the ONLY place LokiSync writes
/// user data, and it never touches the network — File I/O only.
/// </summary>
public sealed class LibraryStorageService
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true
    };

    private readonly string _filePath;

    /// <summary>
    /// Where user-picked track icons are copied to (see MainViewModel's
    /// icon-picker command). Copying rather than referencing the original
    /// picked file means a track's icon keeps working even if the user
    /// later moves, renames, or deletes whatever file they originally
    /// picked it from.
    /// </summary>
    public string CoversDirectory { get; }

    public LibraryStorageService()
    {
        string appDataDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "LokiSync");

        Directory.CreateDirectory(appDataDir);
        _filePath = Path.Combine(appDataDir, "library.json");

        CoversDirectory = Path.Combine(appDataDir, "covers");
        Directory.CreateDirectory(CoversDirectory);
    }

    public LibraryData Load()
    {
        try
        {
            if (!File.Exists(_filePath))
                return new LibraryData();

            string json = File.ReadAllText(_filePath);
            var data = JsonSerializer.Deserialize<LibraryData>(json) ?? new LibraryData();
            NormalizeEqBandArrays(data);
            return data;
        }
        catch (Exception ex)
        {
            // Corrupt or unreadable state file: start fresh rather than crash.
            AppLog.Error("Failed to load library.json; starting with a fresh library.", ex);
            return new LibraryData();
        }
    }

    /// <summary>
    /// Pads/truncates BandGainsDb (top-level and on every preset) to
    /// exactly EqualizerSampleProvider.BandCount entries. Needed because a
    /// save file from before the graphic EQ rework has no BandGainsDb at
    /// all (JSON deserialization leaves the property-initializer default,
    /// which is already the right length), and a save file from a future
    /// build with more bands than this one would otherwise crash band
    /// lookups by index instead of just ignoring the extra bands.
    /// </summary>
    private static void NormalizeEqBandArrays(LibraryData data)
    {
        int bandCount = Audio.EqualizerSampleProvider.BandCount;
        data.BandGainsDb = ResizeToBandCount(data.BandGainsDb, bandCount);
        foreach (var preset in data.EqPresets)
            preset.BandGainsDb = ResizeToBandCount(preset.BandGainsDb, bandCount);
    }

    private static float[] ResizeToBandCount(float[]? gains, int bandCount)
    {
        if (gains is not null && gains.Length == bandCount) return gains;

        var resized = new float[bandCount];
        if (gains is not null)
            Array.Copy(gains, resized, Math.Min(gains.Length, bandCount));
        return resized;
    }

    public void Save(LibraryData data)
    {
        try
        {
            string json = JsonSerializer.Serialize(data, JsonOptions);
            string tempPath = _filePath + ".tmp";
            File.WriteAllText(tempPath, json);

            if (File.Exists(_filePath))
                File.Delete(_filePath);

            File.Move(tempPath, _filePath);
        }
        catch (Exception ex)
        {
            // Saving is best-effort; a failed save should not crash playback.
            AppLog.Error("Failed to save library.json.", ex);
        }
    }
}
