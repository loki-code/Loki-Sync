using System;
using System.Globalization;
using System.Windows.Data;
using LokiSync.Models;
using LokiSync.ViewModels;

namespace LokiSync.Converters;

/// <summary>
/// Packs a Track and a PlaylistViewModel (bound from two different parts of
/// the visual tree via MultiBinding) into the (Track, PlaylistViewModel)
/// tuple that MainViewModel.AddTrackToPlaylistCommand expects as its single
/// CommandParameter. A plain CommandParameter binding can only carry one
/// value, but the "add to playlist" picker menu needs both which track the
/// row belongs to and which playlist the clicked menu item represents.
/// </summary>
public sealed class TrackPlaylistPairConverter : IMultiValueConverter
{
    public static readonly TrackPlaylistPairConverter Instance = new();

    public object? Convert(object[] values, Type targetType, object? parameter, CultureInfo culture)
    {
        if (values.Length == 2 && values[0] is Track track && values[1] is PlaylistViewModel playlist)
        {
            return (track, playlist);
        }

        return null;
    }

    public object[] ConvertBack(object? value, Type[] targetTypes, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}
