using System;
using System.Globalization;
using System.Windows.Data;
using LokiSync.Services;

namespace LokiSync.Converters;

/// <summary>
/// Converts RepeatMode to a Segoe MDL2 Assets glyph rather than a text
/// label. The transport row sits between two icon-only buttons (prev/next),
/// so a "Repeat: All" text label used to be the odd one out in width and
/// visual weight; a single glyph now matches the row. Off/All share the
/// plain repeat glyph (E8EE) since the button's own accent-tinted
/// background already distinguishes "active" from "off" — RepeatOne gets
/// the dedicated "repeat one" glyph (E8ED) so it doesn't need a text badge.
/// Human-readable mode text still lives in the button's ToolTip in XAML.
/// </summary>
public sealed class RepeatModeConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        return value is RepeatMode mode
            ? mode switch
            {
                RepeatMode.RepeatOne => "\uE8ED",
                _ => "\uE8EE"
            }
            : "\uE8EE";
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}
