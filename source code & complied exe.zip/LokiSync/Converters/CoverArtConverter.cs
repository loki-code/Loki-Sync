using System;
using System.Collections.Concurrent;
using System.Globalization;
using System.Linq;
using System.Windows.Data;
using System.Windows.Media.Imaging;

namespace LokiSync.Converters;

/// <summary>
/// Converts a track's CoverArtPath (nullable file path) into a BitmapImage
/// for the row thumbnail. Returns null when there's no path or the file
/// can't be loaded, so the XAML fallback (the placeholder icon) shows
/// through instead of crashing the row.
///
/// Perf notes that matter once a library has more than a handful of
/// icon'd tracks, since this converter runs on the UI thread on every
/// binding re-evaluation for every visible row — not just once on scroll,
/// but also on hover/selection triggers that touch the row's visual tree:
///   - DecodePixelWidth caps the decode to thumbnail resolution, so a
///     user-picked large photo isn't held in memory at full size.
///   - The cache is keyed by path ONLY (not by a File.GetLastWriteTimeUtc
///     stat, which was a synchronous disk I/O call happening on *every*
///     converter invocation — with many visible/hovered rows that adds up
///     to real, repeated blocking I/O on the UI thread, not just on first
///     load). PickTrackIcon always writes to a brand-new GUID-named file
///     rather than overwriting an existing path, so a path is immutable
///     once created and a plain path-keyed cache is safe without the stat.
/// </summary>
public sealed class CoverArtConverter : IValueConverter
{
    public static readonly CoverArtConverter Instance = new();

    /// <summary>
    /// Thumbnails never render larger than ~46px in this UI (transport bar
    /// tile); 64px gives a little headroom for HiDPI without decoding
    /// anywhere near a typical source photo's resolution.
    /// </summary>
    private const int DecodePixelWidth = 64;

    private static readonly ConcurrentDictionary<string, BitmapImage?> Cache = new();

    /// <summary>
    /// Hard ceiling on cached thumbnails. Each is tiny (64px, frozen,
    /// decoded once), but with no cap at all a library where most tracks
    /// get tagged over time would let this grow forever for the life of
    /// the process. This is far above what's ever visible on screen at
    /// once, so it only ever trims memory back for icons that have
    /// scrolled out of view a long time ago.
    /// </summary>
    private const int MaxCacheEntries = 500;

    public object? Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value is not string path || string.IsNullOrWhiteSpace(path)) return null;

        // GetOrAdd with a null-caching factory: a missing/corrupt file is
        // cached as "no image" too, so a bad path doesn't retry hitting
        // the disk (and throwing) on every single row re-render.
        var result = Cache.GetOrAdd(path, static p =>
        {
            try
            {
                var bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.CacheOption = BitmapCacheOption.OnLoad;
                bitmap.DecodePixelWidth = DecodePixelWidth;
                bitmap.UriSource = new Uri(p, UriKind.Absolute);
                bitmap.EndInit();
                bitmap.Freeze();
                return bitmap;
            }
            catch
            {
                return null;
            }
        });

        // Cheap, approximate trim rather than a real LRU: once the cache
        // gets unusually large, drop a batch of arbitrary entries. Exact
        // recency tracking isn't worth the extra bookkeeping here — the
        // point is just to stop unbounded growth over a very long session
        // with a heavily-tagged library, not to optimize which entries
        // survive.
        if (Cache.Count > MaxCacheEntries)
        {
            foreach (var key in Cache.Keys.Take(Cache.Count - MaxCacheEntries))
                Cache.TryRemove(key, out _);
        }

        return result;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();

    /// <summary>
    /// Drops a path's cached bitmap. Call this when a track's icon is
    /// replaced (PickTrackIcon writes a new path each time, so this is
    /// only needed if that ever changes to reuse a path) or removed.
    /// </summary>
    public static void Invalidate(string path) => Cache.TryRemove(path, out _);
}
