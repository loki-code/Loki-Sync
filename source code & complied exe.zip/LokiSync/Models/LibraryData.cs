using System;
using System.Collections.Generic;

namespace LokiSync.Models;

/// <summary>
/// Everything LokiSync persists between runs. Serialized to a single local
/// JSON file under %AppData%\LokiSync — never transmitted anywhere.
/// </summary>
public sealed class LibraryData
{
    /// <summary>Folders the user added; rescanned on startup to rebuild the library.</summary>
    public List<string> WatchedFolders { get; init; } = new();

    public List<Playlist> Playlists { get; init; } = new();

    /// <summary>Last selected/playing track path, for resume-on-launch convenience.</summary>
    public string? LastPlayedPath { get; set; }

    public double LastVolume { get; set; } = 0.8;

    // ================= Equalizer / audio preferences =================
    // Everything below is a player-facing preference the user sets once
    // via the Settings panel and shouldn't have to re-set every launch.
    // Saved through the same LibraryStorageService.Save() path as
    // everything else in this file, so it gets the same atomic-write
    // safety for free.

    /// <summary>
    /// Graphic EQ band gains in dB, one per band (see
    /// EqualizerSampleProvider.BandFrequencies for what each index means).
    /// Null/short arrays (e.g. loaded from an older save file that only
    /// had bass/mid/treble) are padded out to the current band count with
    /// zeros — see LibraryStorageService.
    /// </summary>
    public float[] BandGainsDb { get; set; } = new float[9];

    /// <summary>-1 (full left) .. 0 (center) .. 1 (full right).</summary>
    public float Balance { get; set; }

    /// <summary>Named EQ presets the user has saved, keyed by name.</summary>
    public List<EqPreset> EqPresets { get; init; } = new();

    /// <summary>If true, playback resumes from the last saved position on launch instead of from 0:00.</summary>
    public bool ResumePlaybackPosition { get; set; } = true;

    /// <summary>Playback position (seconds) within LastPlayedPath, used when ResumePlaybackPosition is on.</summary>
    public double LastPlayedPositionSeconds { get; set; }

    public bool RememberShuffle { get; set; } = true;
    public bool LastShuffleEnabled { get; set; }

    public bool RememberRepeatMode { get; set; } = true;
    public string LastRepeatMode { get; set; } = "Off";

    /// <summary>
    /// User-entered artist name and/or picked cover icon, keyed by file
    /// path (case-insensitive). Tracks themselves are rebuilt from disk on
    /// every scan (see LibraryScanService), so anything the user fills in
    /// by hand has to be stored separately here and re-applied after each
    /// scan — otherwise it would just be discarded on the next rescan.
    /// </summary>
    public Dictionary<string, TrackOverride> TrackOverrides { get; init; } = new(StringComparer.OrdinalIgnoreCase);
}

/// <summary>Manually-entered per-track metadata that a folder rescan won't overwrite.</summary>
public sealed class TrackOverride
{
    /// <summary>Null/empty means "no manual artist set" — fall back to whatever the ID3 tag gave.</summary>
    public string? Artist { get; set; }

    /// <summary>Path under %AppData%\LokiSync\covers\ to the user-picked icon, or null if none.</summary>
    public string? CoverArtPath { get; set; }
}

/// <summary>A saved EQ configuration the user can recall by name.</summary>
public sealed class EqPreset
{
    public required string Name { get; set; }

    /// <summary>Graphic EQ band gains in dB, one per band, same order as LibraryData.BandGainsDb.</summary>
    public float[] BandGainsDb { get; set; } = new float[9];
}
