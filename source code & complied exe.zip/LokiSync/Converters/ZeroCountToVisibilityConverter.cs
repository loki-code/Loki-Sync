using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace LokiSync.Converters;

/// <summary>
/// Binds to a collection's Count. 0 -&gt; Visible (show empty-state message),
/// otherwise Collapsed. Pass parameter "Invert" to flip it (e.g. to hide
/// the list itself when empty instead).
/// </summary>
public sealed class ZeroCountToVisibilityConverter : IValueConverter
{
    public static readonly ZeroCountToVisibilityConverter Instance = new();

    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        int count = value switch
        {
            int i => i,
            null => 0,
            _ => 1 // non-null, non-int (e.g. an object): treat as "present"
        };

        bool isZero = count == 0;
        if (string.Equals(parameter as string, "Invert", StringComparison.OrdinalIgnoreCase))
            isZero = !isZero;

        return isZero ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) =>
        throw new NotSupportedException();
}
