using System;
using System.IO;
using System.Text;

namespace LokiSync.Services;

/// <summary>
/// Append-only event log for LokiSync, written to
/// %AppData%\LokiSync\log.txt — the same folder LibraryStorageService
/// uses for library.json, so all of LokiSync's local state lives in one
/// place. File I/O only, never touches the network.
///
/// Rotation: once log.txt reaches 1 MB, it's renamed to log.old (deleting
/// any previous log.old first) and a fresh, empty log.txt is started. That
/// means at most two files ever exist — log.txt (current) and log.old
/// (previous) — so the log can never grow unbounded on disk.
///
/// Static + lock-guarded rather than an injected instance: logging needs
/// to be callable from anywhere in the app (services, view models, the
/// App-level unhandled-exception handlers) without threading a logger
/// reference through every constructor. The internal lock is what makes
/// that safe to call from multiple threads at once — e.g. a playback
/// error on the audio callback thread and a save failure on the UI thread
/// logging at the same moment — without interleaved or corrupted lines.
/// </summary>
public static class AppLog
{
    private const long MaxLogSizeBytes = 1 * 1024 * 1024; // 1 MB

    private static readonly object Gate = new();
    private static readonly string LogDirectory;
    private static readonly string LogPath;
    private static readonly string OldLogPath;

    static AppLog()
    {
        LogDirectory = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "LokiSync");
        LogPath = Path.Combine(LogDirectory, "log.txt");
        OldLogPath = Path.Combine(LogDirectory, "log.old");
    }

    /// <summary>Appends a timestamped info line, rotating log.txt first if needed.</summary>
    public static void Info(string message) => Write("INFO", message);

    /// <summary>Appends a timestamped warning line, rotating log.txt first if needed.</summary>
    public static void Warn(string message) => Write("WARN", message);

    /// <summary>Appends a timestamped error line (with optional exception detail), rotating log.txt first if needed.</summary>
    public static void Error(string message, Exception? exception = null)
    {
        string line = exception is null ? message : $"{message}{Environment.NewLine}{exception}";
        Write("ERROR", line);
    }

    private static void Write(string level, string message)
    {
        // One lock around the whole read-check-rotate-append sequence.
        // Rotation and the write it protects must happen as a single
        // unit — checking the size, rotating, and appending as separate
        // locked steps would let two threads both see "not over 1 MB yet"
        // and both append, or both decide to rotate at once and race each
        // other renaming log.txt to log.old.
        lock (Gate)
        {
            try
            {
                Directory.CreateDirectory(LogDirectory);

                string line = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff}] [{level}] {message}{Environment.NewLine}";
                var lineBytes = Encoding.UTF8.GetByteCount(line);

                // Rotate *before* writing if the file is already at or
                // past the limit, or if this write would push it over.
                // Checking pre-write (rather than writing first and
                // rotating after) means log.txt never grows past
                // MaxLogSizeBytes + a few bytes of slack — it stays a
                // reliable "roughly 1 MB, never much more" cap even under
                // a burst of large log lines.
                if (File.Exists(LogPath))
                {
                    long currentSize = new FileInfo(LogPath).Length;
                    if (currentSize + lineBytes > MaxLogSizeBytes)
                        Rotate();
                }

                File.AppendAllText(LogPath, line, Encoding.UTF8);
            }
            catch
            {
                // Logging is best-effort. A failure to write the log
                // (disk full, permissions, file locked by another
                // process) must never crash or destabilize the app that's
                // trying to log — that would turn a diagnostic feature
                // into a new source of bugs.
            }
        }
    }

    /// <summary>
    /// Deletes any existing log.old, renames the current log.txt to
    /// log.old, and leaves log.txt absent so the next append recreates it
    /// fresh. Must only be called from within the Gate lock.
    /// </summary>
    private static void Rotate()
    {
        if (File.Exists(OldLogPath))
            File.Delete(OldLogPath);

        if (File.Exists(LogPath))
            File.Move(LogPath, OldLogPath);
    }
}
