using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Threading;
using LokiSync.Audio;
using LokiSync.Models;
using LokiSync.Services;
using Microsoft.Win32;

namespace LokiSync.ViewModels;

public sealed class MainViewModel : ObservableObject, IDisposable
{
    private readonly LibraryStorageService _storage;
    private readonly LibraryScanService _scanner;
    private readonly PlaybackService _playback;
    private readonly LibraryData _data;

    // Debounces disk writes triggered by EQ slider drags. A Slider bound
    // with the default UpdateSourceTrigger raises the property setter on
    // every intermediate value while being dragged (dozens of times per
    // second) — writing the full library JSON to disk on every one of
    // those would be constant redundant I/O for a value that only needs
    // to be durable once the user stops moving the slider.
    private readonly DispatcherTimer _eqSaveDebounceTimer;

    // Same debounce shape as _eqSaveDebounceTimer, but shorter — this only
    // delays a UI refresh (not a disk write), so it should still feel
    // "live" while typing. 150ms is short enough that it reads as
    // instant once the user pauses, but long enough to collapse a fast
    // typist's whole burst of keystrokes into a single refresh.
    private readonly DispatcherTimer _searchDebounceTimer;

    private bool _isUpdatingPosition;

    // Guards RescanAsync against overlapping calls. Without this, clicking
    // "Add Folder" (or Rescan) while a scan is already running — very easy
    // to do, since the scan takes a moment and the buttons stay clickable —
    // starts a second concurrent scan. Whichever finishes last wins and
    // clobbers the other, and mid-scan, Library.Clear() from one run can
    // leave the library momentarily empty while the other run's
    // RebuildPlaylistTracks resolves against it — which is how a playlist
    // that genuinely has songs on disk ends up rebuilt as empty. A pending
    // request is coalesced into one follow-up scan instead of stacking.
    private bool _isScanning;
    private bool _rescanRequestedWhileScanning;

    public ObservableCollection<Track> Library { get; } = new();
    public ObservableCollection<PlaylistViewModel> Playlists { get; } = new();

    private Track? _selectedTrack;
    public Track? SelectedTrack
    {
        get => _selectedTrack;
        set
        {
            if (!SetField(ref _selectedTrack, value)) return;
            PlayPauseCommand.RaiseCanExecuteChanged();
        }
    }

    private PlaylistViewModel? _selectedPlaylist;
    public PlaylistViewModel? SelectedPlaylist
    {
        get => _selectedPlaylist;
        set
        {
            if (!SetField(ref _selectedPlaylist, value)) return;
            DeletePlaylistCommand.RaiseCanExecuteChanged();
            AddSelectedTrackToPlaylistCommand.RaiseCanExecuteChanged();
        }
    }

    private Track? _nowPlaying;
    public Track? NowPlaying
    {
        get => _nowPlaying;
        set
        {
            var previous = _nowPlaying;
            if (!SetField(ref _nowPlaying, value)) return;

            // Flip the highlight flags on the old and new track so every
            // list showing them (library, any playlist) updates its row
            // without a full refresh — Track objects are shared by
            // reference everywhere. IsActivelyPlaying tracks IsPlaying
            // below rather than being hardcoded true here, since PlayTrack
            // sets NowPlaying and IsPlaying together but this setter can't
            // assume which order a caller did it in.
            if (previous is not null)
            {
                previous.IsNowPlaying = false;
                previous.IsActivelyPlaying = false;
            }
            if (value is not null)
            {
                value.IsNowPlaying = true;
                value.IsActivelyPlaying = _isPlaying;
            }

            PlayPauseCommand.RaiseCanExecuteChanged();
            NextCommand.RaiseCanExecuteChanged();
            PreviousCommand.RaiseCanExecuteChanged();
        }
    }

    private bool _isPlaying;
    public bool IsPlaying
    {
        get => _isPlaying;
        set
        {
            if (!SetField(ref _isPlaying, value)) return;
            if (_nowPlaying is not null) _nowPlaying.IsActivelyPlaying = value;
        }
    }

    private double _positionSeconds;
    public double PositionSeconds
    {
        get => _positionSeconds;
        set
        {
            if (!SetField(ref _positionSeconds, value)) return;
            if (_isUpdatingPosition) return;
            _playback.Position = TimeSpan.FromSeconds(value);
        }
    }

    private double _durationSeconds = 1;
    public double DurationSeconds
    {
        get => _durationSeconds;
        set => SetField(ref _durationSeconds, value);
    }

    private double _volume;
    public double Volume
    {
        get => _volume;
        set
        {
            if (!SetField(ref _volume, value)) return;
            _playback.Volume = value;
            _data.LastVolume = value;
        }
    }

    private bool _isShuffleEnabled;
    public bool IsShuffleEnabled
    {
        get => _isShuffleEnabled;
        set
        {
            if (!SetField(ref _isShuffleEnabled, value)) return;
            if (_data.RememberShuffle)
            {
                _data.LastShuffleEnabled = value;
                _storage.Save(_data);
            }
        }
    }

    private RepeatMode _repeatMode = RepeatMode.Off;
    public RepeatMode RepeatMode
    {
        get => _repeatMode;
        set
        {
            if (!SetField(ref _repeatMode, value)) return;
            if (_data.RememberRepeatMode)
            {
                _data.LastRepeatMode = value.ToString();
                _storage.Save(_data);
            }
        }
    }

    // ================= Equalizer / audio settings =================
    // Every setter here writes straight through to PlaybackService (so the
    // change is audible immediately) and to _data + Save (so it survives
    // a restart) — the same pattern Volume already used, just applied to
    // the new EQ controls.

    private bool _isSettingsOpen;
    /// <summary>True while the Settings/EQ panel overlay is shown.</summary>
    public bool IsSettingsOpen
    {
        get => _isSettingsOpen;
        set => SetField(ref _isSettingsOpen, value);
    }

    // True only while ApplyPreset (loading a saved preset) is assigning
    // BassGainDb/MidGainDb/TrebleGainDb. Distinguishes "the preset set
    // this" from "the user just dragged a slider away from it", so the
    // preset dropdown correctly deselects itself the moment the live EQ
    // no longer matches what's shown as selected — otherwise the dropdown
    // would keep showing a preset name that no longer reflects the actual
    // sound, which is misleading.
    private bool _isApplyingPreset;

    /// <summary>The 9 graphic EQ bands, low to high frequency. Bound by EqCurveControl to draw/drag the curve.</summary>
    public ObservableCollection<EqBandViewModel> EqBands { get; } = new();

    // Band indices these two quick-boost sliders drive. Kept as a plain
    // array of indices (rather than duplicating BandFrequencies filtering
    // logic) since the mapping is small, fixed, and only used here.
    private static readonly int[] BassBandIndices = { 0, 1, 2 };   // 32 / 64 / 125 Hz
    private static readonly int[] VocalBandIndices = { 4, 5 };     // 500 Hz / 1 kHz

    // Guards against the boost sliders re-entrantly resetting themselves:
    // dragging a graphic-EQ dot changes EqBands, which (via the
    // PropertyChanged hookup below) recomputes BassBoostDb/VocalBoostDb
    // from the new band values — that recomputation must not itself
    // trigger the boost slider's own setter logic (which would push
    // uniform gains back onto every band it owns and clobber whatever the
    // user just dragged one of them to individually).
    private bool _isApplyingBoost;

    private float _bassBoostDb;
    /// <summary>
    /// Quick "more bass" control: uniformly raises/lowers the 32/64/125 Hz
    /// bands together. A shortcut over dragging three separate dots on the
    /// graphic EQ — moving it sets all three bands to the same gain, and
    /// dragging any one of those three bands individually updates this
    /// slider to reflect their (rounded) average, so the two controls
    /// never visibly disagree.
    /// </summary>
    public float BassBoostDb
    {
        get => _bassBoostDb;
        set
        {
            value = Math.Clamp(value, -12f, 12f);
            if (!SetField(ref _bassBoostDb, value)) return;
            ApplyBoost(BassBandIndices, value);
        }
    }

    private float _vocalBoostDb;
    /// <summary>
    /// Quick "more vocal" control: uniformly raises/lowers the 500 Hz /
    /// 1 kHz bands together — the core of vocal presence. Same
    /// shortcut-over-dragging-dots relationship to EqBands as BassBoostDb.
    /// </summary>
    public float VocalBoostDb
    {
        get => _vocalBoostDb;
        set
        {
            value = Math.Clamp(value, -12f, 12f);
            if (!SetField(ref _vocalBoostDb, value)) return;
            ApplyBoost(VocalBandIndices, value);
        }
    }

    private void ApplyBoost(int[] bandIndices, float gainDb)
    {
        _isApplyingBoost = true;
        try
        {
            foreach (int i in bandIndices)
                EqBands[i].GainDb = gainDb;
        }
        finally
        {
            _isApplyingBoost = false;
        }
    }

    /// <summary>
    /// Recomputes a boost slider's displayed value from its underlying
    /// bands' current average, e.g. after a preset load, Reset, or the
    /// user dragging one of those bands' dots directly. Rounds to the
    /// nearest 0.1 dB so tiny floating-point drift between the bands
    /// doesn't make the slider hunt for a value that never quite settles.
    /// </summary>
    private void RefreshBoostSliders()
    {
        float bassAvg = BassBandIndices.Select(i => EqBands[i].GainDb).Average();
        float vocalAvg = VocalBandIndices.Select(i => EqBands[i].GainDb).Average();
        SetField(ref _bassBoostDb, (float)Math.Round(bassAvg, 1), nameof(BassBoostDb));
        SetField(ref _vocalBoostDb, (float)Math.Round(vocalAvg, 1), nameof(VocalBoostDb));
    }

    /// <summary>
    /// Pushed into every EqBandViewModel as its change callback. Mirrors
    /// what the old per-property (BassGainDb/MidGainDb/TrebleGainDb)
    /// setters did: update PlaybackService immediately for audible
    /// feedback, mirror into _data for persistence, debounce the disk
    /// write, and drop the active preset selection once the user has
    /// hand-tweaked away from it.
    /// </summary>
    private void OnBandGainChanged(int band, float gainDb)
    {
        _playback.SetBandGainDb(band, gainDb);
        _data.BandGainsDb[band] = gainDb;
        SaveEqDebounced();
        if (!_isApplyingPreset) SelectedPreset = null;
        if (!_isApplyingBoost) RefreshBoostSliders();
    }

    private float _balance;
    public float Balance
    {
        get => _balance;
        set
        {
            if (!SetField(ref _balance, value)) return;
            _playback.Balance = value;
            _data.Balance = value;
            SaveEqDebounced();
        }
    }

    /// <summary>
    /// Restarts the debounce timer for EQ-related disk saves. Called from
    /// every EQ/balance setter, which — when bound to a Slider being
    /// dragged — can fire dozens of times per second; writing the full
    /// library JSON to disk on each one would be needless I/O for a value
    /// that only needs to be durable once the user stops moving the
    /// slider. The audio itself still updates immediately (see the
    /// _playback.* assignment above this call in each setter) — only the
    /// disk write is delayed.
    /// </summary>
    private void SaveEqDebounced()
    {
        _eqSaveDebounceTimer.Stop();
        _eqSaveDebounceTimer.Start();
    }

    private bool _resumePlaybackPosition;
    public bool ResumePlaybackPosition
    {
        get => _resumePlaybackPosition;
        set
        {
            if (!SetField(ref _resumePlaybackPosition, value)) return;
            _data.ResumePlaybackPosition = value;
            _storage.Save(_data);
        }
    }

    private bool _rememberShuffle;
    public bool RememberShuffle
    {
        get => _rememberShuffle;
        set
        {
            if (!SetField(ref _rememberShuffle, value)) return;
            _data.RememberShuffle = value;
            _storage.Save(_data);
        }
    }

    private bool _rememberRepeatMode;
    public bool RememberRepeatMode
    {
        get => _rememberRepeatMode;
        set
        {
            if (!SetField(ref _rememberRepeatMode, value)) return;
            _data.RememberRepeatMode = value;
            _storage.Save(_data);
        }
    }

    public ObservableCollection<EqPreset> EqPresets { get; } = new();

    private EqPreset? _selectedPreset;
    /// <summary>Currently selected preset in the dropdown; null while the EQ has been hand-tweaked away from any saved preset.</summary>
    public EqPreset? SelectedPreset
    {
        get => _selectedPreset;
        set
        {
            if (!SetField(ref _selectedPreset, value)) return;
            if (value is not null) ApplyPreset(value);
            DeletePresetCommand.RaiseCanExecuteChanged();
        }
    }

    private string _newPresetName = string.Empty;
    public string NewPresetName
    {
        get => _newPresetName;
        set
        {
            if (!SetField(ref _newPresetName, value)) return;
            SavePresetCommand.RaiseCanExecuteChanged();
        }
    }

    private string _statusText = "Ready";
    public string StatusText
    {
        get => _statusText;
        set => SetField(ref _statusText, value);
    }

    private string _searchText = string.Empty;
    /// <summary>Live filter text for the library view (matches title, artist, or album).</summary>
    public string SearchText
    {
        get => _searchText;
        set
        {
            if (!SetField(ref _searchText, value)) return;
            OnPropertyChanged(nameof(HasSearchText));
            // LibraryView.Refresh() re-evaluates the filter across every
            // track AND rebuilds the ListBox's realized containers — with
            // the box bound UpdateSourceTrigger=PropertyChanged, doing that
            // synchronously on every keystroke made typing itself feel
            // laggy on anything but a tiny library. Debouncing means a fast
            // typist only pays for one refresh, after they pause, instead
            // of one per character.
            _searchDebounceTimer.Stop();
            _searchDebounceTimer.Start();
        }
    }

    public bool HasSearchText => !string.IsNullOrWhiteSpace(SearchText);

    /// <summary>Filtered view over Library, bound instead of Library directly so search doesn't mutate the underlying list.</summary>
    public ICollectionView LibraryView { get; }

    // Commands
    public RelayCommand AddFolderCommand { get; }
    public RelayCommand RescanCommand { get; }
    public RelayCommand PlayPauseCommand { get; }
    public RelayCommand NextCommand { get; }
    public RelayCommand PreviousCommand { get; }
    public RelayCommand PlayTrackCommand { get; }
    public RelayCommand CreatePlaylistCommand { get; }
    public RelayCommand DeletePlaylistCommand { get; }
    public RelayCommand AddSelectedTrackToPlaylistCommand { get; }
    public RelayCommand AddTrackToPlaylistCommand { get; }
    public RelayCommand RemoveTrackFromPlaylistCommand { get; }
    /// <summary>Clears SelectedPlaylist, returning the main view to the full Library.</summary>
    public RelayCommand ShowLibraryCommand { get; }
    public RelayCommand ToggleShuffleCommand { get; }
    public RelayCommand CycleRepeatCommand { get; }
    public RelayCommand ClearSearchCommand { get; }
    public RelayCommand BeginRenamePlaylistCommand { get; }
    public RelayCommand CommitRenamePlaylistCommand { get; }
    public RelayCommand OpenSettingsCommand { get; }
    public RelayCommand CloseSettingsCommand { get; }
    public RelayCommand ResetEqCommand { get; }
    public RelayCommand SavePresetCommand { get; }
    public RelayCommand DeletePresetCommand { get; }

    /// <summary>Commits a row's inline artist-name edit. Parameter is the Track being edited.</summary>
    public RelayCommand SetTrackArtistCommand { get; }
    /// <summary>Opens a file picker for a track's icon/cover image. Parameter is the Track being edited.</summary>
    public RelayCommand PickTrackIconCommand { get; }

    public MainViewModel()
    {
        _storage = new LibraryStorageService();
        _scanner = new LibraryScanService();
        _playback = new PlaybackService();
        _data = _storage.Load();

        // Assigned early (before the debounce timers below) so the
        // Tick/command closures that call LibraryView.Refresh() can see
        // it as definitely-assigned — those closures only ever run after
        // construction finishes, but the compiler can't infer that from
        // a later assignment, which is what CS8602 was flagging.
        LibraryView = CollectionViewSource.GetDefaultView(Library);
        LibraryView.Filter = FilterLibraryItem;

        _eqSaveDebounceTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(400) };
        _eqSaveDebounceTimer.Tick += (_, _) =>
        {
            _eqSaveDebounceTimer.Stop();
            _storage.Save(_data);
        };

        _searchDebounceTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(150) };
        _searchDebounceTimer.Tick += (_, _) =>
        {
            _searchDebounceTimer.Stop();
            LibraryView.Refresh();
        };

        _volume = _data.LastVolume;
        _playback.Volume = _volume;

        // Restore every persisted audio/UX preference so the user never has
        // to redo them after closing the app. Assigning through the public
        // properties (not the backing fields) here would re-trigger a Save
        // for each one on startup, which is harmless but wasteful — set the
        // backing fields directly and push the values into PlaybackService
        // once, explicitly.
        _balance = _data.Balance;
        _playback.Balance = _balance;

        // Build the band view-models from the persisted gains (already
        // padded to the current band count by LibraryStorageService) and
        // push each into PlaybackService so the DSP starts up matching
        // what's shown. Every band shares OnBandGainChanged as its
        // callback — that's what makes dragging a point on the curve (or
        // moving a fallback slider) immediately audible and durable.
        for (int i = 0; i < EqualizerSampleProvider.BandCount; i++)
        {
            float gain = i < _data.BandGainsDb.Length ? _data.BandGainsDb[i] : 0f;
            var bandVm = new EqBandViewModel(i, EqualizerSampleProvider.BandFrequencies[i], gain, OnBandGainChanged);
            EqBands.Add(bandVm);
            _playback.SetBandGainDb(i, gain);
        }
        RefreshBoostSliders();

        _resumePlaybackPosition = _data.ResumePlaybackPosition;
        _rememberShuffle = _data.RememberShuffle;
        _rememberRepeatMode = _data.RememberRepeatMode;

        if (_rememberShuffle) _isShuffleEnabled = _data.LastShuffleEnabled;
        if (_rememberRepeatMode && Enum.TryParse<RepeatMode>(_data.LastRepeatMode, out var savedRepeat))
            _repeatMode = savedRepeat;

        foreach (var preset in _data.EqPresets)
            EqPresets.Add(preset);

        _playback.TrackEnded += (_, _) => OnTrackEnded();
        _playback.PositionChanged += (_, _) => OnPositionChanged();
        // AudioFileReader's constructor (called from PlaybackService.Load)
        // throws synchronously for a bad path, so PlayTrack's own try/catch
        // already handles a missing/inaccessible file. This handler instead
        // catches failures that only surface once WasapiOut starts actually
        // reading/playing — a corrupt file, an unsupported codec, or the
        // output device itself failing (e.g. unplugged) — which arrive here
        // asynchronously, after NowPlaying/IsPlaying were already
        // optimistically set to "playing". Roll that state back so the UI
        // doesn't keep showing a track as playing when it isn't.
        _playback.PlaybackFailed += (_, ex) =>
        {
            AppLog.Error("Playback failed.", ex);
            StatusText = $"Playback error: {ex.Message}";
            IsPlaying = false;
            NowPlaying = null;
        };

        AddFolderCommand = RelayCommand.Create(AddFolder);
        // Routed through CreateAsync (not Create with an async lambda) so
        // the command keeps a real Task all the way through instead of
        // silently degrading to async void — see RelayCommand.CreateAsync
        // for why that distinction is the actual fix here.
        RescanCommand = RelayCommand.CreateAsync(RescanSafeAsync);
        PlayPauseCommand = RelayCommand.Create(TogglePlayPause, () => NowPlaying is not null || SelectedTrack is not null);
        NextCommand = RelayCommand.Create(PlayNext, () => NowPlaying is not null);
        PreviousCommand = RelayCommand.Create(PlayPrevious, () => NowPlaying is not null);
        PlayTrackCommand = new RelayCommand(param => { if (param is Track t) PlayOrToggleTrack(t); });
        CreatePlaylistCommand = RelayCommand.Create(CreatePlaylist);
        DeletePlaylistCommand = RelayCommand.Create(DeleteSelectedPlaylist, () => SelectedPlaylist is not null);
        // Kept as a thin wrapper around AddTrackToPlaylist so the old
        // single-argument call shape (used when a playlist is already the
        // one being viewed) still works; the real add-from-Library path
        // now goes through AddTrackToPlaylistCommand below, since relying
        // on SelectedPlaylist as the target meant the button was only ever
        // enabled while a playlist's own tracks were on screen — never
        // while browsing the Library, which is where the button lives.
        AddSelectedTrackToPlaylistCommand = new RelayCommand(
            param => { if (param is Track t) AddTrackToSelectedPlaylist(t); },
            _ => SelectedPlaylist is not null);
        // Explicit (track, target playlist) pair, independent of whatever
        // is currently on screen. This is what the "＋ Playlist" button in
        // the Library actually uses now, via a picker menu listing all
        // playlists.
        AddTrackToPlaylistCommand = new RelayCommand(param =>
        {
            if (param is (Track track, PlaylistViewModel playlist))
            {
                AddTrackToPlaylist(track, playlist);
            }
        });
        RemoveTrackFromPlaylistCommand = new RelayCommand(
            param => { if (param is Track t) RemoveTrackFromSelectedPlaylist(t); });
        ShowLibraryCommand = RelayCommand.Create(() => SelectedPlaylist = null);
        ToggleShuffleCommand = RelayCommand.Create(() => IsShuffleEnabled = !IsShuffleEnabled);
        CycleRepeatCommand = RelayCommand.Create(CycleRepeat);
        ClearSearchCommand = RelayCommand.Create(() =>
        {
            SearchText = string.Empty;
            // A deliberate single click, not a keystroke mid-typing — no
            // reason to make the user wait out the debounce here.
            _searchDebounceTimer.Stop();
            LibraryView.Refresh();
        });
        BeginRenamePlaylistCommand = new RelayCommand(param =>
        {
            if (param is PlaylistViewModel vm) vm.BeginEdit();
        });
        CommitRenamePlaylistCommand = new RelayCommand(param =>
        {
            if (param is PlaylistViewModel vm)
            {
                vm.CommitEdit();
                _storage.Save(_data);
            }
        });
        OpenSettingsCommand = RelayCommand.Create(() => IsSettingsOpen = true);
        CloseSettingsCommand = RelayCommand.Create(() => IsSettingsOpen = false);
        ResetEqCommand = RelayCommand.Create(ResetEq);
        SavePresetCommand = RelayCommand.Create(SaveCurrentAsPreset, () => !string.IsNullOrWhiteSpace(NewPresetName));
        DeletePresetCommand = RelayCommand.Create(DeleteSelectedPreset, () => SelectedPreset is not null);

        SetTrackArtistCommand = new RelayCommand(param =>
        {
            if (param is TrackArtistEdit edit) SetTrackArtist(edit.Track, edit.Artist);
        });
        PickTrackIconCommand = new RelayCommand(param =>
        {
            if (param is Track track) PickTrackIcon(track);
        });

        LoadPlaylistsFromData();
        _ = InitialLoadAsync();
    }

    private bool FilterLibraryItem(object obj)
    {
        if (string.IsNullOrWhiteSpace(SearchText)) return true;
        if (obj is not Track track) return false;

        return Contains(track.DisplayTitle) || Contains(track.Artist) || Contains(track.Album);

        bool Contains(string? field) =>
            !string.IsNullOrEmpty(field) && field.Contains(SearchText, StringComparison.OrdinalIgnoreCase);
    }

    private async Task InitialLoadAsync()
    {
        if (_data.WatchedFolders.Count == 0)
        {
            StatusText = "Add a music folder to get started";
            return;
        }

        await RescanSafeAsync();

        // Load (but don't auto-play) the last track so NowPlaying, the seek
        // bar, and the transport controls all reflect where the user left
        // off — without immediately blasting audio the instant the app
        // opens, which nobody asked for and every other player avoids too.
        if (_data.LastPlayedPath is { } path)
        {
            var track = Library.FirstOrDefault(t =>
                string.Equals(t.FilePath, path, StringComparison.OrdinalIgnoreCase));

            if (track is not null)
            {
                try
                {
                    _playback.Load(track.FilePath);
                    if (_data.ResumePlaybackPosition && _data.LastPlayedPositionSeconds > 0)
                        _playback.Position = TimeSpan.FromSeconds(_data.LastPlayedPositionSeconds);

                    NowPlaying = track;
                    SelectedTrack = track;
                    IsPlaying = false;
                    StatusText = $"Resumed: {track.DisplayTitle} (paused)";
                }
                catch
                {
                    // File may have moved/been deleted since last run —
                    // leave NowPlaying null rather than show a broken
                    // "now playing" row for a file that can't actually play.
                }
            }
        }
    }

    private void AddFolder()
    {
        // OpenFolderDialog is a fully local, in-process Windows shell dialog —
        // no network involved in browsing the local filesystem.
        var dialog = new OpenFolderDialog
        {
            Title = "Select a music folder"
        };

        if (dialog.ShowDialog() == true && !string.IsNullOrWhiteSpace(dialog.FolderName))
        {
            // Normalize away a trailing separator (e.g. "D:\Music\" vs
            // "D:\Music") before comparing/storing. Without this, re-adding
            // the "same" folder a second time (very easy to do, since the
            // shell dialog doesn't always return the same trailing-slash
            // form) can slip past the duplicate check as a "different"
            // entry, or fail to match against an existing one when the two
            // forms mix.
            var normalized = dialog.FolderName.TrimEnd('\\', '/');

            if (!_data.WatchedFolders.Contains(normalized, StringComparer.OrdinalIgnoreCase))
            {
                _data.WatchedFolders.Add(normalized);
                _storage.Save(_data);
            }

            _ = RescanSafeAsync();
        }
    }

    private async Task RescanSafeAsync()
    {
        // A scan is already running — don't start a second one that would
        // race it. Just remember that fresh folders/state showed up while
        // it was busy, so the in-flight scan's own completion triggers one
        // more pass afterward instead of the request being silently lost.
        if (_isScanning)
        {
            _rescanRequestedWhileScanning = true;
            return;
        }

        _isScanning = true;
        try
        {
            do
            {
                _rescanRequestedWhileScanning = false;
                await RescanAsync();
            } while (_rescanRequestedWhileScanning);
        }
        catch (Exception ex)
        {
            StatusText = $"Scan failed: {ex.Message}";
        }
        finally
        {
            _isScanning = false;
        }
    }

    private async Task RescanAsync()
    {
        StatusText = "Scanning local library...";

        // Remember what's currently playing/selected *by path* before the
        // library is rebuilt — Clear()+repopulate below creates brand-new
        // Track instances, so any reference we're still holding (NowPlaying,
        // SelectedTrack) would otherwise become a stale, orphaned object:
        // playback would keep going (PlaybackService is keyed on file path,
        // not on the Track instance) but IsNowPlaying/selection highlighting
        // in the UI would silently desync since it lives on the old instance.
        var nowPlayingPath = NowPlaying?.FilePath;
        var selectedTrackPath = SelectedTrack?.FilePath;

        var tracks = await _scanner.ScanFoldersAsync(_data.WatchedFolders);

        Library.Clear();
        foreach (var track in tracks)
        {
            ApplyTrackOverride(track);
            Library.Add(track);
        }

        // Playlists store file paths only; re-resolve them against the
        // freshly scanned library so playlist contents reflect what's
        // actually on disk right now (handles first load, rescans, and
        // files that were moved/deleted since the playlist was saved).
        foreach (var playlistVm in Playlists)
            RebuildPlaylistTracks(playlistVm);

        // Re-point NowPlaying/SelectedTrack at the new instance for the same
        // path, if it's still there. If the file is gone, fall back to null
        // (SelectedTrack) or leave NowPlaying pointing at nothing playable —
        // playback itself isn't interrupted; it just no longer has a library
        // row to highlight, which is the correct outcome for a deleted file.
        if (nowPlayingPath is not null)
            NowPlaying = Library.FirstOrDefault(t =>
                string.Equals(t.FilePath, nowPlayingPath, StringComparison.OrdinalIgnoreCase));

        if (selectedTrackPath is not null)
            SelectedTrack = Library.FirstOrDefault(t =>
                string.Equals(t.FilePath, selectedTrackPath, StringComparison.OrdinalIgnoreCase));

        // A watched folder that no longer exists (moved/renamed/unplugged
        // drive) is silently skipped by the scan itself — that's correct
        // behavior, but silent is exactly how "why is my library empty"
        // support questions happen. Surface it here instead.
        var missingFolders = _data.WatchedFolders.Where(f => !Directory.Exists(f)).ToList();
        StatusText = missingFolders.Count > 0
            ? $"{Library.Count} track(s) in library — {missingFolders.Count} watched folder(s) not found: {string.Join(", ", missingFolders)}"
            : $"{Library.Count} track(s) in library";
    }

    /// <summary>
    /// Re-applies any manually-entered artist/icon for this track's path
    /// on top of whatever the fresh ID3 scan produced. Called for every
    /// track right after a (re)scan, since Library.Clear() + repopulate
    /// would otherwise silently drop anything the user typed in by hand.
    /// </summary>
    private void ApplyTrackOverride(Track track)
    {
        if (!_data.TrackOverrides.TryGetValue(track.FilePath, out var over)) return;

        if (!string.IsNullOrWhiteSpace(over.Artist))
            track.Artist = over.Artist;

        if (!string.IsNullOrWhiteSpace(over.CoverArtPath) && File.Exists(over.CoverArtPath))
            track.CoverArtPath = over.CoverArtPath;
    }

    /// <summary>
    /// Sets (or clears, if blank) the manually-entered artist name for a
    /// track, live on the Track instance and persisted so it survives the
    /// next rescan. Bound to the row's inline artist textbox.
    /// </summary>
    private void SetTrackArtist(Track track, string? artist)
    {
        artist = artist?.Trim() ?? string.Empty;
        if (artist == track.Artist) return; // no actual edit — skip the disk write

        track.Artist = artist;

        var over = GetOrCreateOverride(track.FilePath);
        over.Artist = string.IsNullOrWhiteSpace(artist) ? null : artist;
        PruneOverrideIfEmpty(track.FilePath, over);

        _storage.Save(_data);
    }

    /// <summary>
    /// Opens a file picker for the row's "add icon" button, copies the
    /// chosen image into the app's local covers folder (so it keeps
    /// working even if the original file moves), and stores it against
    /// this track both live and persisted.
    /// </summary>
    private void PickTrackIcon(Track track)
    {
        var dialog = new OpenFileDialog
        {
            Title = "Choose an icon for this song",
            Filter = "Image files|*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.webp|All files|*.*",
            CheckFileExists = true
        };

        if (dialog.ShowDialog() != true) return;

        try
        {
            string destFileName = $"{Guid.NewGuid():N}.png";
            string destPath = Path.Combine(_storage.CoversDirectory, destFileName);

            SaveResizedCoverArt(dialog.FileName, destPath);

            // Replacing an existing icon: clean up the old copy in the
            // covers folder so it doesn't just accumulate orphaned files.
            string? oldPath = track.CoverArtPath;
            if (!string.IsNullOrWhiteSpace(oldPath) && File.Exists(oldPath) &&
                !string.Equals(oldPath, destPath, StringComparison.OrdinalIgnoreCase))
            {
                Converters.CoverArtConverter.Invalidate(oldPath);
                try { File.Delete(oldPath); } catch { /* best-effort cleanup */ }
            }

            track.CoverArtPath = destPath;

            var over = GetOrCreateOverride(track.FilePath);
            over.CoverArtPath = destPath;
            PruneOverrideIfEmpty(track.FilePath, over);

            _storage.Save(_data);
        }
        catch (Exception ex)
        {
            AppLog.Error("Failed to set track icon.", ex);
            StatusText = "Couldn't set that icon — see log for details.";
        }
    }

    /// <summary>
    /// Longest edge a stored cover icon is allowed to have. The largest
    /// this ever renders at in the UI is the 46px transport-bar tile
    /// (times, say, 3x for a HiDPI display) — 256px is generous headroom
    /// above that. Capping it here (rather than just at display time in
    /// CoverArtConverter) keeps the actual files in %AppData%\LokiSync\covers
    /// small: without this, picking a handful of multi-megabyte photos as
    /// icons could add tens of MB to the covers folder for images that are
    /// never displayed at anywhere near their original size.
    /// </summary>
    private const int MaxCoverArtDimension = 256;

    /// <summary>
    /// Loads the user-picked image, downscales it (if larger than
    /// MaxCoverArtDimension on its longest edge) preserving aspect ratio,
    /// and re-encodes it as PNG at destPath. Re-encoding to a single known
    /// format also means CoverArtConverter never has to deal with an
    /// oddball source format (e.g. some BMP/WEBP variants WPF's decoder is
    /// pickier about) at display time.
    /// </summary>
    private static void SaveResizedCoverArt(string sourcePath, string destPath)
    {
        var source = new System.Windows.Media.Imaging.BitmapImage();
        source.BeginInit();
        source.CacheOption = System.Windows.Media.Imaging.BitmapCacheOption.OnLoad;
        source.UriSource = new Uri(sourcePath, UriKind.Absolute);
        source.EndInit();
        source.Freeze();

        double scale = Math.Min(1.0, MaxCoverArtDimension / (double)Math.Max(source.PixelWidth, source.PixelHeight));
        int width = Math.Max(1, (int)Math.Round(source.PixelWidth * scale));
        int height = Math.Max(1, (int)Math.Round(source.PixelHeight * scale));

        System.Windows.Media.Imaging.BitmapSource resized = scale < 1.0
            ? new System.Windows.Media.Imaging.TransformedBitmap(
                source, new System.Windows.Media.ScaleTransform(scale, scale))
            : source;

        var encoder = new System.Windows.Media.Imaging.PngBitmapEncoder();
        encoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(resized));

        using var fs = new FileStream(destPath, FileMode.Create, FileAccess.Write);
        encoder.Save(fs);
    }

    private TrackOverride GetOrCreateOverride(string filePath)
    {
        if (!_data.TrackOverrides.TryGetValue(filePath, out var over))
        {
            over = new TrackOverride();
            _data.TrackOverrides[filePath] = over;
        }
        return over;
    }

    /// <summary>Drops an override entry once it no longer holds anything, so library.json doesn't accumulate empty stubs.</summary>
    private void PruneOverrideIfEmpty(string filePath, TrackOverride over)
    {
        if (string.IsNullOrWhiteSpace(over.Artist) && string.IsNullOrWhiteSpace(over.CoverArtPath))
            _data.TrackOverrides.Remove(filePath);
    }

    private void TogglePlayPause()
    {
        if (NowPlaying is null)
        {
            if (SelectedTrack is not null) PlayTrack(SelectedTrack);
            return;
        }

        if (IsPlaying)
        {
            _playback.Pause();
            IsPlaying = false;
            if (_data.ResumePlaybackPosition) _storage.Save(_data);
        }
        else
        {
            _playback.Play();
            IsPlaying = true;
        }
    }

    /// <summary>
    /// Used by the per-row play/pause button in the Library and playlist
    /// lists. Clicking the row for whatever's already loaded should behave
    /// like the transport bar's own button (pause/resume in place) rather
    /// than restarting the track from 0:00 — that restart-on-click was the
    /// old PlayTrackCommand behavior and made the row button feel like it
    /// didn't remember what was already playing.
    /// </summary>
    public void PlayOrToggleTrack(Track track)
    {
        if (NowPlaying is not null && NowPlaying.Equals(track))
        {
            TogglePlayPause();
        }
        else
        {
            PlayTrack(track);
        }
    }

    public void PlayTrack(Track track)
    {
        try
        {
            _playback.Load(track.FilePath);
            _playback.Play();
            NowPlaying = track;
            IsPlaying = true;
            _data.LastPlayedPath = track.FilePath;
            _data.LastPlayedPositionSeconds = 0;
            StatusText = $"Playing: {track.DisplayTitle}";
        }
        catch (Exception ex)
        {
            StatusText = $"Could not play file: {ex.Message}";
        }
    }

    private void OnPositionChanged()
    {
        _isUpdatingPosition = true;
        PositionSeconds = _playback.Position.TotalSeconds;
        if (_playback.NaturalDuration is { } duration && duration.TotalSeconds > 0)
            DurationSeconds = duration.TotalSeconds;
        _isUpdatingPosition = false;

        // Kept in memory on every tick (cheap) but only written to disk on
        // pause/exit (see TogglePlayPause/Dispose) — flushing to disk 4x/sec
        // would be needless I/O for a value that only needs to be accurate
        // at the moments playback actually stops.
        if (_data.ResumePlaybackPosition)
            _data.LastPlayedPositionSeconds = PositionSeconds;
    }

    private void OnTrackEnded()
    {
        if (RepeatMode == RepeatMode.RepeatOne && NowPlaying is not null)
        {
            PlayTrack(NowPlaying);
            return;
        }

        PlayNext();
    }

    private void PlayNext()
    {
        var currentList = GetActiveTrackList();
        if (currentList.Count == 0 || NowPlaying is null) return;

        int currentIndex = currentList.FindIndex(t => t.Equals(NowPlaying));

        Track? next;
        if (IsShuffleEnabled && currentList.Count > 1)
        {
            var rnd = new Random();
            int idx;
            do { idx = rnd.Next(currentList.Count); } while (idx == currentIndex);
            next = currentList[idx];
        }
        else if (currentIndex >= 0 && currentIndex < currentList.Count - 1)
        {
            next = currentList[currentIndex + 1];
        }
        else if (RepeatMode == RepeatMode.RepeatAll && currentList.Count > 0)
        {
            next = currentList[0];
        }
        else
        {
            _playback.Stop();
            IsPlaying = false;
            return;
        }

        PlayTrack(next);
    }

    private void PlayPrevious()
    {
        var currentList = GetActiveTrackList();
        if (currentList.Count == 0 || NowPlaying is null) return;

        // Restart current track if more than 3s in, like most players.
        if (_playback.Position.TotalSeconds > 3)
        {
            _playback.Position = TimeSpan.Zero;
            return;
        }

        int currentIndex = currentList.FindIndex(t => t.Equals(NowPlaying));
        if (currentIndex > 0)
        {
            PlayTrack(currentList[currentIndex - 1]);
        }
        else if (RepeatMode == RepeatMode.RepeatAll && currentList.Count > 0)
        {
            PlayTrack(currentList[^1]);
        }
    }

    private List<Track> GetActiveTrackList() =>
        (SelectedPlaylist?.Tracks ?? (IEnumerable<Track>)Library).ToList();

    private void CycleRepeat()
    {
        RepeatMode = RepeatMode switch
        {
            RepeatMode.Off => RepeatMode.RepeatAll,
            RepeatMode.RepeatAll => RepeatMode.RepeatOne,
            _ => RepeatMode.Off
        };
    }

    /// <summary>Applies a saved preset's gains to the live EQ and marks it as the active selection.</summary>
    private void ApplyPreset(EqPreset preset)
    {
        _isApplyingPreset = true;
        try
        {
            for (int i = 0; i < EqBands.Count; i++)
            {
                float gain = i < preset.BandGainsDb.Length ? preset.BandGainsDb[i] : 0f;
                EqBands[i].GainDb = gain;
            }
        }
        finally
        {
            _isApplyingPreset = false;
        }
    }

    private void ResetEq()
    {
        foreach (var band in EqBands)
            band.GainDb = 0;
        Balance = 0;
        SelectedPreset = null;
    }

    private void SaveCurrentAsPreset()
    {
        var name = NewPresetName.Trim();
        if (string.IsNullOrEmpty(name)) return;

        var currentGains = EqBands.Select(b => b.GainDb).ToArray();

        // Overwrite in place if a preset with this name already exists —
        // re-saving under the same name to update it should feel like an
        // update, not produce a confusing duplicate entry in the list.
        var existing = _data.EqPresets.FirstOrDefault(p =>
            string.Equals(p.Name, name, StringComparison.OrdinalIgnoreCase));

        if (existing is not null)
        {
            existing.BandGainsDb = currentGains;

            var existingVm = EqPresets.First(p => ReferenceEquals(p, existing));
            SelectedPreset = existingVm;
        }
        else
        {
            var preset = new EqPreset
            {
                Name = name,
                BandGainsDb = currentGains
            };
            _data.EqPresets.Add(preset);
            EqPresets.Add(preset);
            SelectedPreset = preset;
        }

        _storage.Save(_data);
        NewPresetName = string.Empty;
        StatusText = $"Saved EQ preset \"{name}\"";
        // ApplyPreset (via SelectedPreset's setter above) already restarted
        // the EQ debounce timer for the just-applied gains; the explicit
        // Save just above already covers that pending write, so cancel the
        // timer rather than let it redundantly write the same data again.
        _eqSaveDebounceTimer.Stop();
    }

    private void DeleteSelectedPreset()
    {
        if (SelectedPreset is null) return;

        var name = SelectedPreset.Name;
        _data.EqPresets.Remove(SelectedPreset);
        EqPresets.Remove(SelectedPreset);
        SelectedPreset = null;
        _storage.Save(_data);
        _eqSaveDebounceTimer.Stop();
        StatusText = $"Deleted EQ preset \"{name}\"";
    }

    private void LoadPlaylistsFromData()
    {
        Playlists.Clear();
        foreach (var playlist in _data.Playlists)
        {
            var vm = new PlaylistViewModel(playlist);
            RebuildPlaylistTracks(vm);
            Playlists.Add(vm);
        }
    }

    private void RebuildPlaylistTracks(PlaylistViewModel vm)
    {
        vm.Tracks.Clear();
        foreach (var path in vm.Model.TrackPaths)
        {
            var track = Library.FirstOrDefault(t =>
                string.Equals(t.FilePath, path, StringComparison.OrdinalIgnoreCase));
            if (track is not null)
                vm.Tracks.Add(track);
        }
    }

    private void CreatePlaylist()
    {
        var playlist = new Playlist { Name = GenerateUniquePlaylistName() };
        _data.Playlists.Add(playlist);
        var vm = new PlaylistViewModel(playlist);
        Playlists.Add(vm);
        SelectedPlaylist = vm;
        _storage.Save(_data);

        // New playlists default to a generic "Playlist N" name that almost
        // nobody keeps — jump straight into rename mode so the very next
        // thing the user does is type the name they actually wanted,
        // instead of a separate double-click after the fact.
        vm.BeginEdit();
    }

    /// <summary>
    /// "Playlist N" using the smallest N not already in use, so deleting and
    /// recreating playlists doesn't produce duplicate-looking names (e.g.
    /// two playlists both showing as "Playlist 2" after a delete/recreate).
    /// </summary>
    private string GenerateUniquePlaylistName()
    {
        var existingNames = new HashSet<string>(
            Playlists.Select(p => p.Name), StringComparer.OrdinalIgnoreCase);

        int n = 1;
        string candidate;
        do
        {
            candidate = $"Playlist {n}";
            n++;
        } while (existingNames.Contains(candidate));

        return candidate;
    }

    private void DeleteSelectedPlaylist()
    {
        if (SelectedPlaylist is null) return;

        // Deleting a playlist can't be undone, and a stray misclick on the
        // sidebar's Delete button would otherwise silently wipe it — confirm first.
        var result = MessageBox.Show(
            $"Delete \"{SelectedPlaylist.Name}\"? This can't be undone.",
            "Delete Playlist",
            MessageBoxButton.YesNo,
            MessageBoxImage.Warning,
            MessageBoxResult.No);

        if (result != MessageBoxResult.Yes) return;

        _data.Playlists.Remove(SelectedPlaylist.Model);
        Playlists.Remove(SelectedPlaylist);
        SelectedPlaylist = null;
        _storage.Save(_data);
    }

    private void AddTrackToSelectedPlaylist(Track track)
    {
        if (SelectedPlaylist is null) return;
        AddTrackToPlaylist(track, SelectedPlaylist);
    }

    private void AddTrackToPlaylist(Track track, PlaylistViewModel playlist)
    {
        if (!playlist.Model.TrackPaths.Contains(track.FilePath, StringComparer.OrdinalIgnoreCase))
        {
            playlist.Model.TrackPaths.Add(track.FilePath);
            playlist.Tracks.Add(track);
            _storage.Save(_data);
        }
    }

    private void RemoveTrackFromSelectedPlaylist(Track track)
    {
        if (SelectedPlaylist is null) return;

        SelectedPlaylist.Model.TrackPaths.RemoveAll(p =>
            string.Equals(p, track.FilePath, StringComparison.OrdinalIgnoreCase));
        SelectedPlaylist.Tracks.Remove(track);
        _storage.Save(_data);
    }

    public void Dispose()
    {
        // Stop the debounce timer rather than let it fire mid-shutdown —
        // the explicit Save below already covers its pending write, since
        // every EQ setter updates _data synchronously and only delays the
        // disk I/O, not the in-memory value.
        //
        // Both timers are DispatcherTimers, thread-affine to the UI thread
        // that created them — Dispose() itself may now be running on a
        // background thread (see MainWindow_Closing), so Stop() has to be
        // routed back to that thread rather than called directly.
        StopOnOwningThread(_eqSaveDebounceTimer);
        StopOnOwningThread(_searchDebounceTimer);
        // PositionSeconds/_data.LastPlayedPositionSeconds is already kept
        // current on every tick (see OnPositionChanged); this Save is what
        // actually persists that in-memory value to disk before exit, so a
        // close without ever pausing still resumes at the right spot.
        _storage.Save(_data);
        _playback.Dispose();
    }

    private static void StopOnOwningThread(DispatcherTimer timer)
    {
        if (timer.Dispatcher.CheckAccess())
            timer.Stop();
        else
            timer.Dispatcher.Invoke(timer.Stop);
    }
}
