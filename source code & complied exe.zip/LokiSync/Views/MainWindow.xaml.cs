using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using LokiSync.Models;
using LokiSync.ViewModels;

namespace LokiSync.Views;

public partial class MainWindow : Window
{
    private readonly MainViewModel _viewModel;

    // Guards against re-entrancy: the first Closing hides the window and
    // kicks off disposal in the background instead of blocking on it, then
    // calls Close() again once disposal finishes to actually exit. Without
    // this flag that second Close() would just re-trigger Closing and hide
    // an already-hidden window forever instead of ever shutting down.
    private bool _isClosingForReal;

    public MainWindow()
    {
        InitializeComponent();
        _viewModel = new MainViewModel();
        DataContext = _viewModel;
        Closing += MainWindow_Closing;

        // The window's own content is fully dark-themed, but the native
        // Windows title bar is drawn by the OS and defaults to white/light
        // regardless of our theme — it isn't part of the WPF visual tree at
        // all. Ask DWM to render it in dark mode instead so there's no
        // mismatched white strip along the top of the window.
        SourceInitialized += (_, _) => TryEnableDarkTitleBar();
    }

    /// <summary>
    /// MainViewModel.Dispose() can block for up to ~2s (see PlaybackService's
    /// bounded wait for WASAPI to actually stop), which made the close
    /// button feel frozen even though it looks like a normal window close.
    /// So: hide the window immediately so the UI feels instant, run the
    /// real disposal on a background thread, then re-invoke Close() once
    /// it's done so the process actually exits.
    /// </summary>
    private void MainWindow_Closing(object? sender, System.ComponentModel.CancelEventArgs e)
    {
        if (_isClosingForReal) return;

        e.Cancel = true;
        Hide();

        System.Threading.Tasks.Task.Run(() => _viewModel.Dispose())
            .ContinueWith(_ =>
            {
                _isClosingForReal = true;
                Close();
            }, System.Threading.Tasks.TaskScheduler.FromCurrentSynchronizationContext());
    }

    private void TryEnableDarkTitleBar()
    {
        try
        {
            var hwnd = new WindowInteropHelper(this).Handle;
            if (hwnd == System.IntPtr.Zero) return;

            int useImmersiveDarkMode = 1;

            // Attribute 20 (DWMWA_USE_IMMERSIVE_DARK_MODE) is the value used
            // on Windows 10 20H1+ and Windows 11. Older builds (pre-20H1)
            // used 19 instead, so try both — a failed call here is harmless
            // and just leaves the title bar light, never crashes the app.
            if (DwmSetWindowAttribute(hwnd, DwmwaUseImmersiveDarkMode, ref useImmersiveDarkMode, sizeof(int)) != 0)
            {
                DwmSetWindowAttribute(hwnd, DwmwaUseImmersiveDarkModeLegacy, ref useImmersiveDarkMode, sizeof(int));
            }
        }
        catch
        {
            // Theming the native title bar is a cosmetic nicety, not a
            // functional requirement — never let it take the app down.
        }
    }

    private const int DwmwaUseImmersiveDarkMode = 20;
    private const int DwmwaUseImmersiveDarkModeLegacy = 19;

    [DllImport("dwmapi.dll", PreserveSig = true)]
    private static extern int DwmSetWindowAttribute(
        System.IntPtr hwnd, int attribute, ref int pvAttribute, int cbAttribute);

    private void MinimizeButton_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;

    private void MaximizeRestoreButton_Click(object sender, RoutedEventArgs e) =>
        WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;

    private void CloseButton_Click(object sender, RoutedEventArgs e) => Close();

    /// <summary>
    /// Player-style keyboard shortcuts: Space play/pause, Ctrl+Right/Left
    /// next/previous, Ctrl+F focuses search, Ctrl+Up/Down nudges volume.
    /// Deliberately skipped whenever a TextBox has focus (search box,
    /// playlist rename box) so typing a space or arrow key in those still
    /// does the ordinary text-editing thing instead of hijacking playback.
    /// </summary>
    private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Escape && _viewModel.IsSettingsOpen)
        {
            _viewModel.CloseSettingsCommand.Execute(null);
            e.Handled = true;
            return;
        }

        if (Keyboard.FocusedElement is TextBox) return;

        switch (e.Key)
        {
            case Key.Space:
                _viewModel.PlayPauseCommand.Execute(null);
                e.Handled = true;
                break;

            case Key.Right when Keyboard.Modifiers == ModifierKeys.Control:
                _viewModel.NextCommand.Execute(null);
                e.Handled = true;
                break;

            case Key.Left when Keyboard.Modifiers == ModifierKeys.Control:
                _viewModel.PreviousCommand.Execute(null);
                e.Handled = true;
                break;

            case Key.Up when Keyboard.Modifiers == ModifierKeys.Control:
                _viewModel.Volume = System.Math.Min(1.0, _viewModel.Volume + 0.1);
                e.Handled = true;
                break;

            case Key.Down when Keyboard.Modifiers == ModifierKeys.Control:
                _viewModel.Volume = System.Math.Max(0.0, _viewModel.Volume - 0.1);
                e.Handled = true;
                break;

            case Key.F when Keyboard.Modifiers == ModifierKeys.Control:
                SearchBox.Focus();
                SearchBox.SelectAll();
                e.Handled = true;
                break;
        }
    }

    /// <summary>Double-clicking a track row plays it immediately, matching common player conventions.</summary>
    private void Track_MouseDoubleClick(object sender, MouseButtonEventArgs e)
    {
        if (sender is ListBox { SelectedItem: Track track })
        {
            _viewModel.PlayTrack(track);
        }
    }

    /// <summary>
    /// Opens the "＋ Playlist" button's own ContextMenu on a normal left
    /// click. A ContextMenu attached via Button.ContextMenu only opens on
    /// right-click/Shift-F10 by default; left-clicking it here is what
    /// makes it behave like the picker button it visually looks like.
    /// </summary>
    private void AddToPlaylistButton_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not FrameworkElement { ContextMenu: { } menu } button) return;
        menu.PlacementTarget = button;
        menu.IsOpen = true;
    }

    /// <summary>Double-clicking a playlist's name label switches the sidebar row into inline-rename mode.</summary>
    private void PlaylistLabel_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ClickCount != 2) return;
        if (sender is not FrameworkElement { DataContext: PlaylistViewModel vm }) return;

        _viewModel.BeginRenamePlaylistCommand.Execute(vm);
    }

    /// <summary>
    /// Focuses and selects the rename TextBox as soon as it becomes visible.
    /// This fires both when double-clicking an existing playlist's name and
    /// when a brand-new playlist is created (MainViewModel.CreatePlaylist
    /// enters edit mode immediately) — one mechanism covers both entry
    /// points instead of each caller having to know to focus the box itself.
    /// </summary>
    private void RenameBox_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
    {
        if (sender is not TextBox { IsVisible: true } box) return;

        // The box has just become visible but hasn't finished its layout
        // pass yet — focusing on the next dispatcher tick ensures it can
        // actually receive keyboard focus and that SelectAll has real text
        // to select.
        Dispatcher.BeginInvoke(new System.Action(() =>
        {
            box.Focus();
            box.SelectAll();
        }), System.Windows.Threading.DispatcherPriority.Input);
    }

    /// <summary>Losing focus (click elsewhere) commits whatever name is currently typed.</summary>
    private void RenameBox_LostFocus(object sender, RoutedEventArgs e)
    {
        // Escape already exits edit mode via RenameBox_KeyDown; only commit
        // here if we're still actually in edit mode, so Escape doesn't
        // trigger a second, redundant save right behind it.
        if (sender is TextBox { DataContext: PlaylistViewModel { IsEditing: true } vm })
        {
            _viewModel.CommitRenamePlaylistCommand.Execute(vm);
        }
    }

    /// <summary>Enter commits the rename; Escape cancels back to the previous name.</summary>
    private void RenameBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (sender is not TextBox { DataContext: PlaylistViewModel vm }) return;

        if (e.Key == Key.Enter)
        {
            _viewModel.CommitRenamePlaylistCommand.Execute(vm);
            e.Handled = true;
        }
        else if (e.Key == Key.Escape)
        {
            vm.CancelEdit();
            e.Handled = true;
        }
    }

    /// <summary>
    /// Single commit point for artist edits — losing focus (click away, or
    /// via Keyboard.ClearFocus() below) saves whatever's currently typed.
    /// Enter/Escape both just move focus rather than committing directly,
    /// so there's exactly one save per edit instead of Enter committing
    /// and then the LostFocus it triggers committing again right behind it.
    /// </summary>
    private void ArtistBox_LostFocus(object sender, RoutedEventArgs e)
    {
        if (sender is TextBox { DataContext: Track track } box)
            _viewModel.SetTrackArtistCommand.Execute(new TrackArtistEdit(track, box.Text));
    }

    /// <summary>Enter commits (via the LostFocus it triggers) and moves focus off the box; Escape reverts to the track's current value first so the LostFocus commit is a no-op change.</summary>
    private void ArtistBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (sender is not TextBox { DataContext: Track track } box) return;

        if (e.Key == Key.Enter)
        {
            Keyboard.ClearFocus();
            e.Handled = true;
        }
        else if (e.Key == Key.Escape)
        {
            box.Text = track.Artist;
            Keyboard.ClearFocus();
            e.Handled = true;
        }
    }

    /// <summary>Clicking the dimmed backdrop behind the Settings panel closes it, matching standard modal-overlay behavior.</summary>
    private void SettingsScrim_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        _viewModel.CloseSettingsCommand.Execute(null);
    }
}
