# LokiSync

A lightweight, fully offline music player for Windows 10/11.

## Stack

- C# / .NET 10
- WPF, MVVM (no third-party MVVM framework — a minimal `RelayCommand` +
  `ObservableObject` are included in `ViewModels/`)
- Playback via `System.Windows.Media.MediaPlayer` (Windows Media Foundation
  under the hood) — plays local files only
- Local JSON persistence at `%AppData%\LokiSync\library.json`

## Why it's offline by default

- No `HttpClient`, no `WebClient`, no networking API is used anywhere in
  the codebase.
- `LokiSync.csproj` pulls in **zero** NuGet packages.
- The app's network capability in `app.manifest`/project settings is not
  requested; nothing here needs Windows network permission.
- ID3 tag reading (`Services/AudioMetadataReader.cs`) parses tag bytes
  straight from the local file — it does **not** call out to any
  metadata service (no MusicBrainz/Last.fm/etc.).
- Persistence (`Services/LibraryStorageService.cs`) is plain local file
  I/O — a single JSON file under `%AppData%\LokiSync`.
- Folder browsing uses `Microsoft.Win32.OpenFolderDialog`, an in-process
  local shell dialog.

If you later want online features (lyrics fetch, cover art lookup,
scrobbling, auto-update), keep them behind an explicit opt-in setting so
the app stays offline-by-default.

## Project layout

```
LokiSync/
  LokiSync.csproj
  App.xaml / App.xaml.cs
  Models/
    Track.cs            Local audio file + parsed tags
    Playlist.cs          Named ordered list of track paths
    LibraryData.cs       Root object persisted to disk
  Services/
    AudioMetadataReader.cs   Local ID3v2 tag parsing
    LibraryScanService.cs    Recursive local folder scan
    LibraryStorageService.cs JSON load/save (local disk only)
    PlaybackService.cs       MediaPlayer wrapper (local file playback)
  ViewModels/
    ObservableObject.cs   INotifyPropertyChanged base
    RelayCommand.cs       ICommand implementation
    PlaylistViewModel.cs  UI wrapper around Playlist
    MainViewModel.cs      App state, commands, playback control
  Views/
    MainWindow.xaml(.cs)  Library / playlists / playback bar UI
  Converters/
    SecondsToTimeConverter, RepeatModeConverter,
    NullToVisibilityConverter, PlayPauseTextConverter
  Resources/
    Theme.xaml            Dark theme styles
```

## Building

Requires the .NET 10 SDK with the Windows desktop workload (or Visual
Studio 2022+/2026 with the ".NET Desktop Development" workload).

```powershell
cd LokiSync
dotnet build
dotnet run --project LokiSync
```

Or open `LokiSync.sln` in Visual Studio and press F5.

> This environment doesn't have the .NET SDK or Windows installed, so the
> code hasn't been compiled here — review it (or open in VS) before
> shipping. The code follows standard WPF/.NET patterns throughout.

## Using it

1. Click **Add Folder** and pick a folder containing audio files
   (`.mp3`, `.wav`, `.wma`, `.m4a`, `.flac`, `.aac`, `.ogg`).
2. The library populates from that folder (recursively). Click **Rescan**
   any time after adding/removing files on disk.
3. Click **Play** (or double-click a row) to start a track, or select it
   and use the transport controls at the bottom.
4. Create playlists in the left sidebar; use **+ Playlist** next to a
   library track to add it to the currently selected playlist.
   Double-click a playlist's name to rename it inline (Enter to confirm,
   Escape to cancel); **Delete** asks for confirmation first.
5. Use the search box above the library to filter by title, artist, or
   album as you type.
6. Shuffle and Repeat (Off / All / One) are available in the playback bar.
7. The currently playing track is marked with a small dot wherever it
   appears (library or any playlist), and helpful empty-state messages
   guide you when the library or a playlist has nothing in it yet.

Watched folders, playlists, volume, and last-played track are saved to
`%AppData%\LokiSync\library.json` automatically and restored next launch
(the app doesn't auto-resume playback on startup, only rescans your
folders).

## Notes on "no logging for now"

There's intentionally no logging framework (no Serilog/NLog/EventLog
calls) wired in. Failures (bad tags, scan errors, playback errors) are
caught and either silently ignored (non-critical, e.g. one corrupt file
during a scan) or surfaced briefly in the status bar at the bottom of the
window, rather than written anywhere. If you want diagnostics later,
`PlaybackService.PlaybackFailed` and the catch blocks in
`AudioMetadataReader`/`LibraryStorageService` are the natural hook points.
